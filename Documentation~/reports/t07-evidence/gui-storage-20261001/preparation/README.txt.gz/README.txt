NB_FX GUI-0 候选：现有共享存储接缝 + Count 类型 + 可选 Vector ST
2026-10-01；普通 URP Mesh 优先。仅 preview，尚未集成/Unity 实测。

1. 文件与交接
候选目录 /tmp/nbfx-gui0-candidate/，相对路径与 Packages/NB_FX 一致：
  XuanXuanRenderUtility/Runtime/ShaderFlagsBase.cs
  NBShaders2/Runtime/NBShaderFlags.cs
  XuanXuanRenderUtility/Editor/ShaderGUIItems/GradientItem.cs
  XuanXuanRenderUtility/Editor/ShaderGUIItems/TextureItem.cs
每文件 unified diff 在 diffs/；source-manifest.json 含现有/候选 SHA256。
生成器 /tmp/nbfx-gui0-build-preview.py 只读现有文件，输出上述候选。
没有将候选写回产品。Root 集成前校验 source-manifest 的 original_sha256；
若现有文件变化，请重新合并 diff，不盲目覆盖。
新测试（本代理唯一仓库写入）：
/Users/bytedance/UnityProject/NBUnityProject/Packages/NB_FX/Tests/URP/Editor/G4GraphGuiStorageTests.cs
及 .meta；副本在 test-snapshot/。
测试过滤名 NBFX.Baseline.Tests.G4GraphGuiStorageTests（预计 46 NUnit cases）。
不能在未集成候选的旧 backend 上把本 fixture 当通过测试。

2. 精确 API/默认语义
ShaderFlagsBase 增两个 protected virtual hooks：
  int ReadWord(int propertyId, MaterialPropertyBlock propertyBlock = null)
  void WriteWord(int propertyId, int value, MaterialPropertyBlock propertyBlock = null)
默认实现仍直接 Material/MPB.GetInteger 与 SetInteger；不做 float 重解释、
不读取后再规范化旧整数。原 Set/Clear/CheckFlagBits 的 OR/AND/any-bit 检查
及 null Material set/clear no-op、check NullReferenceException 保持。
原公开方法仍是原类原方法，通过 virtual hooks 接管物理存储；没有 new 隐藏方法。
NBShaderFlags 的现有 UV/ColorChannel/PNoise typed 方法仅把直接读写改走同一 hooks；
其位移/清位/除余数/负 PNoise sentinel 等算法不变。CustomData 不触碰。

NBShaderFlags 在 Material 路径用实际 property signature 判断 Graph：
必须同时有 _NB_DistortionMode、_NB_Flags0Lo16/Hi16、_NB_Flags1Lo16/Hi16。
不依赖 shader.name、不缓存材质 shader；各目标 pair 又必须两半都存在。
八个既有逻辑 word 映射（不是新增协议/属性）：
  slot0 _W9ParticleShaderFlags -> _NB_Flags0Lo16/Hi16
  slot1 _W9ParticleShaderFlags1 -> _NB_Flags1Lo16/Hi16
  slot2 _W9ParticleShaderWrapFlags -> _NB_WrapFlagsLo16/Hi16
  slot6 _W9ParticleShaderColorChannelFlag -> _NB_ColorChannelLo16/Hi16
  slot7 _W9ParticleShaderPNoiseBlendFlag -> _NB_PNoiseBlendLo16/Hi16 （PN1已接入）
  slot8 _NBShaderForceNoMipFlags -> _NB_ForceNoMipFlagsLo16/Hi16
  _UVModeFlag0 -> _NB_UVModeFlag0Lo16/Hi16
  _UVModeFlagType0 -> _NB_UVModeFlagType0Lo16/Hi16
读：clamp[0,65535]后 RoundToInt，两 uint 半字合并、unchecked int保留bit31；
不在读取时改写异常/小数材质值。写：uint word低/高16分别写exact float；
写入仅作用目标word，不动其他word。目标word中未修改位保持。
MPB 没有 Graph schema，永远走原整数property IDs（即使拥有者是Graph材质）。
未知/缺pair word同样回默认整数路径；这不表示Graph支持那些缺省word功能。
slot3/4/5 foldouts、CustomData Graph协议仍pending；不造影子int属性。

GradientItem：private ReadCountValue/WriteCountValue/GetDefaultCountValue；
原Int路径仍intValue/defaultInt，小规模GraphFloat count读RoundToInt(floatValue)、
写floatValue、defaultFloat取整。原color/alpha打包及Key算法/Reset同一实现不复制。
最多6|(6<<16)=393222 exact float32。只本Count，不转换旧flags为单Float。

TextureItem/TexturePropertyGroupItem 各追加 optional string scaleOffsetPropertyName=null。
null/empty完全使用原TextureScaleOffsetItem(texturePropertyName,isVectorProperty=false)；
明确给vector名则复用同一TextureScaleOffsetItem(...,isVectorProperty=true)。
没有新增ST控件算法。drawScaleOffset=false仍完全不构造ST（MatCap）。
将来 Graph BaseMap控件传 scaleOffsetPropertyName:"_BaseMap_ST"；其他texture默认原生ST。
本片不改Root调用点，故并不声称Graph正式GUI已经启用该选项。
新增optional参数对现有源码调用兼容，但构造器CLR签名变化，已有预编译使用方
必须重编译；当前Unity源包全部重编译可检验，跨版本/安装兼容仍后续阶段。

3. 测试证据边界（没有运行，不称通过）
46 cases 设计为实际 Material + 实际 NBShaderFlags/共享控件后台，不模拟另一套产品。
URP测试asmdef无NB引用，使用 test-only reflection找已加载类型、调用真实方法；
未改asmdef，没有产品反射或新GUI系统。
- 六mapped slots每word32位（含31）设置/清除/读/重复，Graph及旧Int均保留无关位。
- 原Material全部九Int word dense值（>float精确整数字区间）；MPB全部九Int word，
  Graph拥有者的Material半字不随MPB写变化；nullMaterial语义和SetMaterial换宿主。
- 13有限值含负值/小数/越界/halfway-tie，分别测lo/hi读取不变/实际写canonicalize。
- 内存创建Shader的Mesh word unit-probe直接include现有NBGraphFlags.hlsl，
  32 finite pairs×2render，linear ARGBFloat/RGBAFloat strict读回lo/hi/bit31/bit0，
  有非零响应与重复检查；不创建shader资产文件，不改HLSL。不以CPU相同公式自证
  GPU round，若当前Metal halfway-tie不同将明确失败，不能猜修/放宽。
- UV16位置×9mode（0..8），两个word未知位保持、mode8 bit31边界、缺席反事实。
- Channel10当前消费者fields×4，Wrap16 U/V成对×4，NoMip18现有bit（只是存储）。
- PNoise Graph/旧材质5三位fields×0..5及负sentinel；枚举命名实际仍0..3；
  4/5是原field合法存储值/原HLSL default source，不新增效果或GUI枚举。
- 实际共享Gradient写/读2..6 color×2..6 alpha、BW2..6、Count0/1/2/6/
  65535/65536/131074/393222、部分word保留、旧Int dense无float损失、Reset。
- 原nativeST/Graph显式vectorST写/Reset、Graph其他贴图nativeST、MatCap无ST。
- 两材质bitword独立存储、caller-owned Undo/Redo，还原不同原值；多选FloatCount
  与VectorST写两对象。不能把它称作原控件/Sync整个Undo事务已实现。

NaN cast在原HLSL无定义，本候选不擅自增NaN=0规则，不声称NaN CPU/GPU等价。
±Infinity未测；有限非法值及GPU ties由Root上述probe验证。
只后端存储/小控件接口测试，不代表正式Inspector/保存重导入/可见绘制通过。

4. 已完成的验证仅限离线编译
static-compile/：用Unity6000.3.18f1现有Bee RSP与Roslyn，所有源文件按实际程序集
完整编译（候选替换四份源码），未启动Unity。
  com.xuanxuan.render.utility : exit0
  com.xuanxuan.nb.shaders2 : exit0，引用前项候选程序集
  com.xuanxuan.render.utility.Editor : exit0，引用前项候选runtime
  NBFX.G4.GUI0.Tests : exit0，新fixture（无NB直接引用）
保留 .rsp/.log/.dll/.pdb。首次试用NonParallelizable发现当前Unity NUnit无该属性，
已移除；Root仍独占串行运行。没有Assert.Multiple。compile-preview.py可重放。
四个现有产品文件hash仍等于original_sha256；无Unity/Git/push/official/Assets/ProjectSettings。

5. 留给后续，而非停工
不切Root、不新增全controls/foldouts/intent/migration、不改Tier/default allowlist/Resolver，
不改关键词/Pass/SubTarget/NBPostprocess/ShaderLab/ShaderGraph/HLSL/Renderer。
需要Root后续GUI1/2/3解决构造capability、实际属性名、intent版本化seed、URP状态
唯一所有权、Tier有效输入、callbacks Undo、保存重导入与最后人工可见Inspector。
GraphMPB/VFX/Player不在本测试范围，完整普通Mesh G3/G4仍未放行。
