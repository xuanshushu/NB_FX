from pathlib import Path
import subprocess,json
clone=Path('/tmp/NBFXG2DissolveMaskProbe-20260928')
repo=Path('/Users/bytedance/UnityProject/NBUnityProject')
out=Path('/tmp/nbfx-gui0-candidate')
bee=clone/'Library/Bee/artifacts/200b0aEDbg.dag'
prefix='Packages/com.xuanxuan.nb.fx/'
selected={
'XuanXuanRenderUtility/Runtime/ShaderFlagsBase.cs',
'NBShaders2/Runtime/NBShaderFlags.cs',
'XuanXuanRenderUtility/Editor/ShaderGUIItems/GradientItem.cs',
'XuanXuanRenderUtility/Editor/ShaderGUIItems/TextureItem.cs'}
assemblies=['com.xuanxuan.render.utility','com.xuanxuan.nb.shaders2','com.xuanxuan.render.utility.Editor']
compiled={}
csdir=out/'static-compile';csdir.mkdir(exist_ok=True)
def run(name,lines):
    path=csdir/(name+'.rsp');path.write_text('\n'.join(lines)+'\n')
    sdk='/Applications/Unity/Hub/Editor/6000.3.18f1/Unity.app/Contents/Resources/Scripting/'
    p=subprocess.run([sdk+'NetCoreRuntime/dotnet',sdk+'DotNetSdkRoslyn/csc.dll','@'+str(path)],cwd=clone,capture_output=True,text=True)
    (csdir/(name+'.log')).write_text(p.stdout+p.stderr)
    print(name,'exit',p.returncode,p.stdout,p.stderr)
    if p.returncode:raise SystemExit(p.returncode)
for name in assemblies:
    lines=(bee/(name+'.rsp')).read_text().splitlines()
    actual=[]
    for line in lines:
        if line.startswith('-out:'):line='-out:"'+str(csdir/(name+'.dll'))+'"'
        elif line.startswith('-refout:'):continue
        elif line.startswith('"'+prefix):
            relative=line[1:-1][len(prefix):]
            line='"'+str((out/relative) if relative in selected else (repo/'Packages/NB_FX'/relative))+'"'
        elif line.startswith('-r:"Library/Bee/'):
            for dep,dll in compiled.items():
                if line.endswith('/'+dep+'.ref.dll"'):line='-r:"'+str(dll)+'"';break
        actual.append(line)
    run(name,actual)
    compiled[name]=csdir/(name+'.dll')
lines=Path('/tmp/nbfx-matcap-csc.rsp').read_text().splitlines()
lines=[line for line in lines if not (line.startswith('-out:') or line.startswith('"/Users/'))]
lines+=['-out:"'+str(csdir/'NBFX.G4.GUI0.StaticCheck.dll')+'"','"'+str(repo/'Packages/NB_FX/Tests/URP/Editor/G4GraphGuiStorageTests.cs')+'"']
run('NBFX.G4.GUI0.Tests',lines)
