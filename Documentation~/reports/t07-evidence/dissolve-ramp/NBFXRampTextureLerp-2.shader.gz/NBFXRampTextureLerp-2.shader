Shader "Hidden/VFX/NBFXRampTextureLerp/Simple Loop/Output Particle Shader Graph Mesh - Unlit"
{
Properties
{
[NoScaleOffset]_BaseMap("BaseMap", 2D) = "white" {}
_Color("Color", Color) = (1, 1, 1, 1)
_NB_DistortionNoise("NB_DistortionNoise", Vector, 2) = (0.25, 0, 0, 0)
_NB_DistortionIntensity("NB_DistortionIntensity", Float) = 0.25
_NB_DistortionMode("NB_DistortionMode", Float) = 0
_NB_Flags0Lo16("NB_Flags0Lo16", Float) = 0
_NB_Flags0Hi16("NB_Flags0Hi16", Float) = 0
_NB_Flags1Lo16("NB_Flags1Lo16", Float) = 0
_NB_Flags1Hi16("NB_Flags1Hi16", Float) = 0
_NB_DistortionAlphaPow("NB_DistortionAlphaPow", Float) = 1
_NB_DistortionAlphaMultiplier("NB_DistortionAlphaMultiplier", Float) = 1
_NB_DistortionAlphaAdd("NB_DistortionAlphaAdd", Float) = 0
_MaskMap("MaskMap", 2D) = "white" {}
_Mask_Toggle("Mask_Toggle", Float) = 0
_MaskMapVec("MaskMapVec", Vector, 4) = (1, 0, 0, 0)
_MaskRefineVec("MaskRefineVec", Vector, 4) = (1, 1, 0, 0)
_NB_ColorChannelLo16("NB_ColorChannelLo16", Float) = 3
_BaseMap_ST("BaseMap ST", Vector, 4) = (1, 1, 0, 0)
_BaseMapUVRotation("BaseMap UV Rotation", Float) = 0
_BaseMapUVRotationSpeed("BaseMap UV Rotation Speed", Float) = 0
_BaseMapMaskMapOffset("BaseMap MaskMap Offset", Vector, 4) = (0, 0, 0, 0)
_MaskMapUVRotation("MaskMap UV Rotation", Float) = 0
_MaskMapRotationSpeed("MaskMap Rotation Speed", Float) = 0
_MaskMapOffsetAnition("MaskMap Offset Anition", Vector, 4) = (0, 0, 0, 0)
_DissolveOffsetRotateDistort("Dissolve Offset Rotate Distort", Vector, 4) = (0, 0, 0, 0)
_DissolveMaskMap("DissolveMaskMap", 2D) = "white" {}
_DissolveMask_Toggle("DissolveMask_Toggle", Float) = 0
[Enum(ProcessDissolve, 0, DissolveMask, 1)]_DissolveMaskMode("DissolveMaskMode", Float) = 0
_MaskMap2("MaskMap2", 2D) = "white" {}
_Mask2_Toggle("Mask2_Toggle", Float) = 0
_MaskMap3("MaskMap3", 2D) = "white" {}
_Mask3_Toggle("Mask3_Toggle", Float) = 0
_MaskMap3OffsetAnition("MaskMap3OffsetAnition", Vector, 4) = (0, 0, 0, 0)
_NB_WrapFlagsLo16("NB_WrapFlagsLo16", Float) = 0
_NB_WrapFlagsHi16("NB_WrapFlagsHi16", Float) = 0
_MaskMapGradientCount("MaskMapGradientCount", Float) = 2
_MaskMapGradientFloat0("MaskMapGradientFloat0", Vector, 4) = (0, 0, 1, 1)
_MaskMapGradientFloat1("MaskMapGradientFloat1", Vector, 4) = (1, 0, 1, 1)
_MaskMapGradientFloat2("MaskMapGradientFloat2", Vector, 4) = (1, 0, 1, 1)
_MaskMap2GradientCount("MaskMap2GradientCount", Float) = 2
_MaskMap2GradientFloat0("MaskMap2GradientFloat0", Vector, 4) = (0, 0, 1, 1)
_MaskMap2GradientFloat1("MaskMap2GradientFloat1", Vector, 4) = (1, 0, 1, 1)
_MaskMap2GradientFloat2("MaskMap2GradientFloat2", Vector, 4) = (1, 0, 1, 1)
_MaskMap3GradientCount("MaskMap3GradientCount", Float) = 2
_MaskMap3GradientFloat0("MaskMap3GradientFloat0", Vector, 4) = (0, 0, 1, 1)
_MaskMap3GradientFloat1("MaskMap3GradientFloat1", Vector, 4) = (1, 0, 1, 1)
_MaskMap3GradientFloat2("MaskMap3GradientFloat2", Vector, 4) = (1, 0, 1, 1)
_AlphaAll("AlphaAll", Float) = 1
_ColorA("ColorA", Vector, 4) = (1, 1, 1, 1)
_BaseColorIntensityForTimeline("BaseColorIntensityForTimeline", Range(0, 10)) = 1
_fresnelEnabled("FresnelEnabled", Float) = 0
_FresnelUnit("FresnelUnit", Vector, 4) = (0, 0.5, 1, 0.5)
[HDR]_FresnelColor("FresnelColor", Color) = (1, 1, 1, 1)
_FresnelRotation("FresnelRotation", Vector, 4) = (0, 0, 0, 0.5)
_Dissolve_Vec2("DissolveLineRange", Vector, 4) = (0.2, 0.1, 0, 0)
[HDR]_DissolveLineColor("DissolveLineColor", Color) = (1, 0, 0, 1)
_Dissolve_useRampMap_Toggle("DissolveRampToggle", Float) = 0
_DissolveRampMap("DissolveRampMap", 2D) = "white" {}
_DissolveRampSourceMode("DissolveRampSourceMode", Float) = 0
[HDR]_DissolveRampColor("DissolveRampColor", Color) = (1, 1, 1, 1)
_DissolveRampCount("DissolveRampCount", Float) = 131074
_DissolveRampColor0("DissolveRampColor0", Color) = (1, 0, 0, 0)
_DissolveRampColor1("DissolveRampColor1", Color) = (0, 0, 0, 1)
_DissolveRampColor2("DissolveRampColor2", Color) = (1, 1, 1, 1)
_DissolveRampColor3("DissolveRampColor3", Color) = (1, 1, 1, 1)
_DissolveRampColor4("DissolveRampColor4", Color) = (1, 1, 1, 1)
_DissolveRampColor5("DissolveRampColor5", Color) = (1, 1, 1, 1)
_DissolveRampAlpha0("DissolveRampAlpha0", Vector, 4) = (1, 0, 1, 1)
_DissolveRampAlpha1("DissolveRampAlpha1", Vector, 4) = (1, 0, 1, 1)
_DissolveRampAlpha2("DissolveRampAlpha2", Vector, 4) = (1, 0, 1, 1)
_NB_ForceNoMipFlagsLo16("NB_ForceNoMipFlagsLo16", Float) = 0
_NB_ForceNoMipFlagsHi16("NB_ForceNoMipFlagsHi16", Float) = 0
_DissolveMap("DissolveMap", 2D) = "grey" {}
_Dissolve_Toggle("Dissolve_Toggle", Float) = 0
_Dissolve("Dissolve", Vector, 4) = (0.5, 1, 1, 0.1)
[HDR]_BaseBackColor("BaseBackColor", Color) = (1, 1, 1, 1)
_EmissionMap("EmissionMap", 2D) = "white" {}
_EmissionEnabled("EmissionEnabled", Float) = 0
_EmissionMapUVOffset("EmissionMapUVOffset", Vector, 4) = (0, 0, 0, 0)
_EmissionMapUVRotation("EmissionMapUVRotation", Range(0, 360)) = 0
[HDR]_EmissionMapColor("EmissionMapColor", Color) = (1, 1, 1, 1)
_EmissionMapColorIntensity("EmissionMapColorIntensity", Float) = 1
_EmissionAlphaIntensity("EmissionAlphaIntensity", Range(0, 1)) = 1
_ColorBlendMap("ColorBlendMap", 2D) = "white" {}
_ColorBlendMap_Toggle("ColorBlendMapToggle", Float) = 0
_ColorBlendMapOffset("ColorBlendMapOffset", Vector, 4) = (0, 0, 0, 0)
_ColorBlendVec("ColorBlendVec", Vector, 4) = (0, 0, 1, 0)
[HDR]_ColorBlendColor("ColorBlendColor", Color) = (1, 1, 1, 1)
_ColorBlendColorIntensity("ColorBlendColorIntensity", Float) = 1
_RampColorMap("RampColorMap", 2D) = "white" {}
_RampColorToggle("RampColorToggle", Float) = 0
_RampColorSourceMode("RampColorSourceMode", Float) = 0
_RampColorMapOffset("RampColorMapOffset", Vector, 4) = (0, 0, 0, 0)
_RampColor0("RampColor0", Color) = (0, 0, 0, 0)
_RampColor1("RampColor1", Color) = (1, 0, 0, 1)
_RampColor2("RampColor2", Color) = (1, 1, 1, 1)
_RampColor3("RampColor3", Color) = (1, 1, 1, 1)
_RampColor4("RampColor4", Color) = (1, 1, 1, 1)
_RampColor5("RampColor5", Color) = (1, 1, 1, 1)
_RampColorAlpha0("RampColorAlpha0", Vector, 4) = (1, 0, 1, 1)
_RampColorAlpha1("RampColorAlpha1", Vector, 4) = (1, 0, 1, 1)
_RampColorAlpha2("RampColorAlpha2", Vector, 4) = (1, 0, 1, 1)
_RampColorCount("RampColorCount", Float) = 131074
[HDR]_RampColorBlendColor("RampColorBlendColor", Color) = (1, 1, 1, 1)
_HueShift("HueShift", Float) = 0
_Contrast("Contrast", Float) = 1
_ContrastMidColor("ContrastMidColor", Color) = (0.5, 0.5, 0.5, 1)
_Saturability("Saturability", Range(0, 1)) = 0
_BaseMapColorRefine("BaseMapColorRefine", Vector, 4) = (1, 1, 2, 0.5)
[HideInInspector]_CastShadows("_CastShadows", Float) = 0
[HideInInspector]_Surface("_Surface", Float) = 1
[HideInInspector]_Blend("_Blend", Float) = 0
[HideInInspector]_AlphaClip("_AlphaClip", Float) = 0
[HideInInspector]_SrcBlend("_SrcBlend", Float) = 1
[HideInInspector]_DstBlend("_DstBlend", Float) = 0
[HideInInspector]_SrcBlendAlpha("_SrcBlendAlpha", Float) = 1
[HideInInspector]_DstBlendAlpha("_DstBlendAlpha", Float) = 0
[HideInInspector][ToggleUI]_ZWrite("_ZWrite", Float) = 0
[HideInInspector]_ZWriteControl("_ZWriteControl", Float) = 0
[HideInInspector]_ZTest("_ZTest", Float) = 4
[HideInInspector]_Cull("_Cull", Float) = 0
[HideInInspector]_AlphaToMask("_AlphaToMask", Float) = 0
[HideInInspector]_QueueOffset("_QueueOffset", Float) = 0
[HideInInspector]_QueueControl("_QueueControl", Float) = -1
[HideInInspector][NoScaleOffset]unity_Lightmaps("unity_Lightmaps", 2DArray) = "" {}
[HideInInspector][NoScaleOffset]unity_LightmapsInd("unity_LightmapsInd", 2DArray) = "" {}
[HideInInspector][NoScaleOffset]unity_ShadowMasks("unity_ShadowMasks", 2DArray) = "" {}
}
SubShader
{
Tags
{
"RenderPipeline"="UniversalPipeline"
"RenderType"="Transparent"
"UniversalMaterialType" = "Unlit"
"Queue"="Transparent"
"DisableBatching"="False"
"ShaderGraphShader"="true"
"ShaderGraphTargetId"="NBGraphUnlitSubTarget"
}
Pass
{
    Name "Universal Forward"
    Tags
    {
        // LightMode: <None>
    }

// Render State
Cull [_Cull]
Blend [_SrcBlend] [_DstBlend], [_SrcBlendAlpha] [_DstBlendAlpha]
ZTest [_ZTest]
ZWrite [_ZWrite]
AlphaToMask [_AlphaToMask]

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma multi_compile _ LIGHTMAP_ON
#pragma multi_compile _ DIRLIGHTMAP_COMBINED
#pragma multi_compile _ USE_LEGACY_LIGHTMAPS
#pragma multi_compile _ LIGHTMAP_BICUBIC_SAMPLING
#pragma multi_compile_fragment _ _DBUFFER_MRT1 _DBUFFER_MRT2 _DBUFFER_MRT3
#pragma multi_compile_fragment _ DEBUG_DISPLAY
#pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
#pragma shader_feature_fragment _ _SURFACE_TYPE_TRANSPARENT
#pragma shader_feature_local_fragment _ _ALPHAPREMULTIPLY_ON
#pragma shader_feature_local_fragment _ _ALPHAMODULATE_ON
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_UNLIT
#define _FOG_FRAGMENT 1


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Fog.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DBuffer.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float3 BaseColor;
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.BaseColor = (_NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.xyz);
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/UnlitPass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "NBCameraOpaqueDistortPass"
    Tags
    {
        "LightMode" = "NBCameraOpaqueDistortPass"
    }

// Render State
Cull [_Cull]
Blend SrcAlpha OneMinusSrcAlpha
ZTest [_ZTest]
ZWrite Off

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma multi_compile _ LIGHTMAP_ON
#pragma multi_compile _ DIRLIGHTMAP_COMBINED
#pragma multi_compile _ USE_LEGACY_LIGHTMAPS
#pragma multi_compile _ LIGHTMAP_BICUBIC_SAMPLING
#pragma multi_compile_fragment _ _DBUFFER_MRT1 _DBUFFER_MRT2 _DBUFFER_MRT3
#pragma multi_compile_fragment _ DEBUG_DISPLAY
#pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
#pragma shader_feature_fragment _ _SURFACE_TYPE_TRANSPARENT
#pragma shader_feature_local_fragment _ _ALPHAPREMULTIPLY_ON
#pragma shader_feature_local_fragment _ _ALPHAMODULATE_ON
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_UNLIT
#define _FOG_FRAGMENT 1


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Fog.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DBuffer.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float3 BaseColor;
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.BaseColor = (_NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.xyz);
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/Passes/NBGraphCameraOpaquePass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "NBDeferredDistortPass"
    Tags
    {
        "LightMode" = "NBDeferredDistortPass"
    }

// Render State
Cull [_Cull]
Blend SrcAlpha OneMinusSrcAlpha
ZTest [_ZTest]
ZWrite Off

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma multi_compile _ LIGHTMAP_ON
#pragma multi_compile _ DIRLIGHTMAP_COMBINED
#pragma multi_compile _ USE_LEGACY_LIGHTMAPS
#pragma multi_compile _ LIGHTMAP_BICUBIC_SAMPLING
#pragma multi_compile_fragment _ _DBUFFER_MRT1 _DBUFFER_MRT2 _DBUFFER_MRT3
#pragma multi_compile_fragment _ DEBUG_DISPLAY
#pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
#pragma shader_feature_fragment _ _SURFACE_TYPE_TRANSPARENT
#pragma shader_feature_local_fragment _ _ALPHAPREMULTIPLY_ON
#pragma shader_feature_local_fragment _ _ALPHAMODULATE_ON
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_UNLIT
#define _FOG_FRAGMENT 1


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Fog.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DBuffer.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float3 BaseColor;
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.BaseColor = (_NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.xyz);
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/Passes/NBGraphDeferredDistortPass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "DepthOnly"
    Tags
    {
        "LightMode" = "DepthOnly"
    }

// Render State
Cull [_Cull]
ZTest LEqual
ZWrite On
ColorMask R

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_DEPTHONLY


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/DepthOnlyPass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "DepthNormalsOnly"
    Tags
    {
        "LightMode" = "DepthNormalsOnly"
    }

// Render State
Cull [_Cull]
ZTest LEqual
ZWrite On

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma multi_compile_fragment _ _GBUFFER_NORMALS_OCT
#pragma shader_feature_fragment _ _SURFACE_TYPE_TRANSPARENT
#pragma shader_feature_local_fragment _ _ALPHAPREMULTIPLY_ON
#pragma shader_feature_local_fragment _ _ALPHAMODULATE_ON
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_DEPTHNORMALSONLY


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/DepthNormalsOnlyPass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "GBuffer"
    Tags
    {
        "LightMode" = "UniversalGBuffer"
    }

// Render State
Cull [_Cull]
Blend [_SrcBlend] [_DstBlend], [_SrcBlendAlpha] [_DstBlendAlpha]
ZTest [_ZTest]
ZWrite [_ZWrite]

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma exclude_renderers gles3 glcore
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma multi_compile_fragment _ _DBUFFER_MRT1 _DBUFFER_MRT2 _DBUFFER_MRT3
#pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
#pragma multi_compile_fragment _ _RENDER_PASS_ENABLED
#pragma multi_compile_fragment _ _GBUFFER_NORMALS_OCT
#pragma multi_compile _ SHADOWS_SHADOWMASK
#pragma shader_feature_fragment _ _SURFACE_TYPE_TRANSPARENT
#pragma shader_feature_local_fragment _ _ALPHAPREMULTIPLY_ON
#pragma shader_feature_local_fragment _ _ALPHAMODULATE_ON
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_GBUFFER


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DBuffer.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if !defined(LIGHTMAP_ON)
 float3 sh;
#endif
#if defined(USE_APV_PROBE_OCCLUSION)
 float4 probeOcclusion;
#endif
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
#if !defined(LIGHTMAP_ON)
 float3 sh : INTERP0;
#endif
#if defined(USE_APV_PROBE_OCCLUSION)
 float4 probeOcclusion : INTERP1;
#endif
 float4 texCoord0 : INTERP2;
 float4 color : INTERP3;
 float3 positionWS : INTERP4;
 float3 normalWS : INTERP5;
nointerpolation float4 worldToElement0 : INTERP6;
nointerpolation float4 worldToElement1 : INTERP7;
nointerpolation float4 worldToElement2 : INTERP8;
nointerpolation float4 elementToWorld0 : INTERP9;
nointerpolation float4 elementToWorld1 : INTERP10;
nointerpolation float4 elementToWorld2 : INTERP11;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
#if !defined(LIGHTMAP_ON)
output.sh = input.sh;
#endif
#if defined(USE_APV_PROBE_OCCLUSION)
output.probeOcclusion = input.probeOcclusion;
#endif
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
#if !defined(LIGHTMAP_ON)
output.sh = input.sh;
#endif
#if defined(USE_APV_PROBE_OCCLUSION)
output.probeOcclusion = input.probeOcclusion;
#endif
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float3 BaseColor;
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.BaseColor = (_NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.xyz);
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/UnlitGBufferPass.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/GBufferOutputFormat.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "SceneSelectionPass"
    Tags
    {
        "LightMode" = "SceneSelectionPass"
    }

// Render State
Cull Off

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_DEPTHONLY
#define SCENESELECTIONPASS 1
#define ALPHA_CLIP_THRESHOLD 1


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/SelectionPickingPass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
Pass
{
    Name "ScenePickingPass"
    Tags
    {
        "LightMode" = "Picking"
    }

// Render State
Cull [_Cull]

// Debug
// <None>

// --------------------------------------------------
// Pass

HLSLPROGRAM

// Pragmas
#pragma target 4.5
#pragma vertex VertVFX
#pragma fragment frag

// Keywords
#pragma shader_feature_local_fragment _ _ALPHATEST_ON
// GraphKeywords: <None>

// Defines
#define HAVE_VFX_MODIFICATION

#define ATTRIBUTES_NEED_NORMAL
#define ATTRIBUTES_NEED_TANGENT
#define ATTRIBUTES_NEED_TEXCOORD0
#define ATTRIBUTES_NEED_COLOR
#define FEATURES_GRAPH_VERTEX_NORMAL_OUTPUT
#define FEATURES_GRAPH_VERTEX_TANGENT_OUTPUT
#define VARYINGS_NEED_POSITION_WS
#define VARYINGS_NEED_NORMAL_WS
#define VARYINGS_NEED_TEXCOORD0
#define VARYINGS_NEED_COLOR
#define VARYINGS_NEED_ELEMENT_TO_WORLD
#define VARYINGS_NEED_WORLD_TO_ELEMENT
#define VARYINGS_NEED_CULLFACE
#define FEATURES_GRAPH_VERTEX
/* WARNING: $splice Could not find named fragment 'PassInstancing' */
#define SHADERPASS SHADERPASS_DEPTHONLY
#define SCENEPICKINGPASS 1
#define ALPHA_CLIP_THRESHOLD 1


// custom interpolator pre-include
/* WARNING: $splice Could not find named fragment 'sgci_CustomInterpolatorPreInclude' */

// Includes
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Texture.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRendering.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Input.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/TextureStack.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/DebugMipmapStreamingMacros.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ShaderGraphFunctions.hlsl"
#include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/DOTS.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/ShaderPass.hlsl"

// --------------------------------------------------
// Structs and Packing

// custom interpolators pre packing
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPrePacking' */

struct Attributes
{
 float3 positionOS : POSITION;
 float3 normalOS : NORMAL;
 float4 tangentOS : TANGENT;
 float4 uv0 : TEXCOORD0;
 float4 color : COLOR;
 uint instanceID : INSTANCEID_SEMANTIC;
 uint vertexID : VERTEXID_SEMANTIC;
};
struct VertexDescriptionInputs
{
 float3 ObjectSpaceNormal;
 float3 ObjectSpaceTangent;
 float3 ObjectSpacePosition;
};
struct SurfaceDescriptionInputs
{
 float3 WorldSpaceNormal;
 float3 WorldSpaceViewDirection;
 float4 uv0;
 float4 VertexColor;
 float FaceSign;
 float4 _Color;
 float2 _NB_DistortionNoise;
 float _NB_DistortionIntensity;
 float _NB_DistortionMode;
 float _NB_Flags0Lo16;
 float _NB_Flags0Hi16;
 float _NB_Flags1Lo16;
 float _NB_Flags1Hi16;
 float _NB_DistortionAlphaPow;
 float _NB_DistortionAlphaMultiplier;
 float _NB_DistortionAlphaAdd;
 float _Mask_Toggle;
 float4 _MaskMapVec;
 float4 _MaskRefineVec;
 float _NB_ColorChannelLo16;
 float4 _BaseMap_ST;
 float _BaseMapUVRotation;
 float _BaseMapUVRotationSpeed;
 float4 _BaseMapMaskMapOffset;
 float _MaskMapUVRotation;
 float _MaskMapRotationSpeed;
 float4 _MaskMapOffsetAnition;
 float4 _DissolveOffsetRotateDistort;
 float _DissolveMask_Toggle;
 float _DissolveMaskMode;
 float _Mask2_Toggle;
 float _Mask3_Toggle;
 float4 _MaskMap3OffsetAnition;
 float _NB_WrapFlagsLo16;
 float _NB_WrapFlagsHi16;
 float _MaskMapGradientCount;
 float4 _MaskMapGradientFloat0;
 float4 _MaskMapGradientFloat1;
 float4 _MaskMapGradientFloat2;
 float _MaskMap2GradientCount;
 float4 _MaskMap2GradientFloat0;
 float4 _MaskMap2GradientFloat1;
 float4 _MaskMap2GradientFloat2;
 float _MaskMap3GradientCount;
 float4 _MaskMap3GradientFloat0;
 float4 _MaskMap3GradientFloat1;
 float4 _MaskMap3GradientFloat2;
 float _AlphaAll;
 float4 _ColorA;
 float _BaseColorIntensityForTimeline;
 float _fresnelEnabled;
 float4 _FresnelUnit;
 float4 _FresnelColor;
 float4 _FresnelRotation;
 float4 _Dissolve_Vec2;
 float4 _DissolveLineColor;
 float _Dissolve_useRampMap_Toggle;
 float _DissolveRampSourceMode;
 float4 _DissolveRampColor;
 float _DissolveRampCount;
 float4 _DissolveRampColor0;
 float4 _DissolveRampColor1;
 float4 _DissolveRampColor2;
 float4 _DissolveRampColor3;
 float4 _DissolveRampColor4;
 float4 _DissolveRampColor5;
 float4 _DissolveRampAlpha0;
 float4 _DissolveRampAlpha1;
 float4 _DissolveRampAlpha2;
 float _NB_ForceNoMipFlagsLo16;
 float _NB_ForceNoMipFlagsHi16;
 float _Dissolve_Toggle;
 float4 _Dissolve;
 float4 _BaseBackColor;
 float _EmissionEnabled;
 float4 _EmissionMapUVOffset;
 float _EmissionMapUVRotation;
 float4 _EmissionMapColor;
 float _EmissionMapColorIntensity;
 float _EmissionAlphaIntensity;
 float _ColorBlendMap_Toggle;
 float4 _ColorBlendMapOffset;
 float4 _ColorBlendVec;
 float4 _ColorBlendColor;
 float _ColorBlendColorIntensity;
 float _RampColorToggle;
 float _RampColorSourceMode;
 float4 _RampColorMapOffset;
 float4 _RampColor0;
 float4 _RampColor1;
 float4 _RampColor2;
 float4 _RampColor3;
 float4 _RampColor4;
 float4 _RampColor5;
 float4 _RampColorAlpha0;
 float4 _RampColorAlpha1;
 float4 _RampColorAlpha2;
 float _RampColorCount;
 float4 _RampColorBlendColor;
 float _HueShift;
 float _Contrast;
 float4 _ContrastMidColor;
 float _Saturability;
 float4 _BaseMapColorRefine;
};
struct Varyings
{
 float4 positionCS : SV_POSITION;
 float3 positionWS;
 float3 normalWS;
 float4 texCoord0;
 float4 color;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
nointerpolation float4 worldToElement0;
nointerpolation float4 worldToElement1;
nointerpolation float4 worldToElement2;
nointerpolation float4 elementToWorld0;
nointerpolation float4 elementToWorld1;
nointerpolation float4 elementToWorld2;
};
struct InternalAttributesElement
{
 float3 position;
 float alive;
 float pivotX;
 float pivotY;
 float pivotZ;
 float size;
 float scaleX;
 float scaleY;
 float scaleZ;
 float3 axisX;
 float3 axisY;
 float3 axisZ;
 float angleX;
 float angleY;
 float angleZ;
};
struct InternalSourceAttributesElement
{
};
struct PackedVaryings
{
 float4 positionCS : SV_POSITION;
 float4 texCoord0 : INTERP0;
 float4 color : INTERP1;
 float3 positionWS : INTERP2;
 float3 normalWS : INTERP3;
nointerpolation float4 worldToElement0 : INTERP4;
nointerpolation float4 worldToElement1 : INTERP5;
nointerpolation float4 worldToElement2 : INTERP6;
nointerpolation float4 elementToWorld0 : INTERP7;
nointerpolation float4 elementToWorld1 : INTERP8;
nointerpolation float4 elementToWorld2 : INTERP9;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
 uint instanceID : CUSTOM_INSTANCE_ID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
 uint stereoTargetEyeIndexAsBlendIdx0 : BLENDINDICES0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
 uint stereoTargetEyeIndexAsRTArrayIdx : SV_RenderTargetArrayIndex;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
 FRONT_FACE_TYPE cullFace : FRONT_FACE_SEMANTIC;
#endif
};

PackedVaryings PackVaryings (Varyings input)
{
PackedVaryings output;
ZERO_INITIALIZE(PackedVaryings, output);
output.positionCS = input.positionCS;
output.texCoord0.xyzw = input.texCoord0;
output.color.xyzw = input.color;
output.positionWS.xyz = input.positionWS;
output.normalWS.xyz = input.normalWS;
output.worldToElement0.xyzw = input.worldToElement0;
output.worldToElement1.xyzw = input.worldToElement1;
output.worldToElement2.xyzw = input.worldToElement2;
output.elementToWorld0.xyzw = input.elementToWorld0;
output.elementToWorld1.xyzw = input.elementToWorld1;
output.elementToWorld2.xyzw = input.elementToWorld2;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}

Varyings UnpackVaryings (PackedVaryings input)
{
Varyings output;
output.positionCS = input.positionCS;
output.texCoord0 = input.texCoord0.xyzw;
output.color = input.color.xyzw;
output.positionWS = input.positionWS.xyz;
output.normalWS = input.normalWS.xyz;
output.worldToElement0 = input.worldToElement0.xyzw;
output.worldToElement1 = input.worldToElement1.xyzw;
output.worldToElement2 = input.worldToElement2.xyzw;
output.elementToWorld0 = input.elementToWorld0.xyzw;
output.elementToWorld1 = input.elementToWorld1.xyzw;
output.elementToWorld2 = input.elementToWorld2.xyzw;
#if UNITY_ANY_INSTANCING_ENABLED || defined(VARYINGS_NEED_INSTANCEID)
output.instanceID = input.instanceID;
#endif
#if (defined(UNITY_STEREO_MULTIVIEW_ENABLED)) || (defined(UNITY_STEREO_INSTANCING_ENABLED) && (defined(SHADER_API_GLES3) || defined(SHADER_API_GLCORE)))
output.stereoTargetEyeIndexAsBlendIdx0 = input.stereoTargetEyeIndexAsBlendIdx0;
#endif
#if (defined(UNITY_STEREO_INSTANCING_ENABLED))
output.stereoTargetEyeIndexAsRTArrayIdx = input.stereoTargetEyeIndexAsRTArrayIdx;
#endif
#if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
output.cullFace = input.cullFace;
#endif
return output;
}


// --------------------------------------------------
// Graph

// Graph Properties
CBUFFER_START(UnityPerMaterial)
float4 _BaseMap_TexelSize;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
UNITY_TEXTURE_STREAMING_DEBUG_VARS;
CBUFFER_END


// Object and Global properties
SAMPLER(SamplerState_Linear_Repeat);
TEXTURE2D(_BaseMap);
SAMPLER(sampler_BaseMap);
TEXTURE2D(_MaskMap);
SAMPLER(sampler_MaskMap);
TEXTURE2D(_DissolveMap);
SAMPLER(sampler_DissolveMap);
TEXTURE2D(_DissolveMaskMap);
SAMPLER(sampler_DissolveMaskMap);
TEXTURE2D(_MaskMap2);
SAMPLER(sampler_MaskMap2);
TEXTURE2D(_MaskMap3);
SAMPLER(sampler_MaskMap3);
TEXTURE2D(_EmissionMap);
SAMPLER(sampler_EmissionMap);
TEXTURE2D(_ColorBlendMap);
SAMPLER(sampler_ColorBlendMap);
TEXTURE2D(_RampColorMap);
SAMPLER(sampler_RampColorMap);
TEXTURE2D(_DissolveRampMap);
SAMPLER(sampler_DissolveRampMap);
struct GraphProperties
{
float4 _BaseMap_TexelSize;
float4 _Color;
float2 _NB_DistortionNoise;
float _NB_DistortionIntensity;
float _NB_DistortionMode;
float _NB_Flags0Lo16;
float _NB_Flags0Hi16;
float _NB_Flags1Lo16;
float _NB_Flags1Hi16;
float _NB_DistortionAlphaPow;
float _NB_DistortionAlphaMultiplier;
float _NB_DistortionAlphaAdd;
float4 _MaskMap_TexelSize;
float4 _MaskMap_ST;
float _Mask_Toggle;
float4 _MaskMapVec;
float4 _MaskRefineVec;
float _NB_ColorChannelLo16;
float4 _DissolveMap_TexelSize;
float4 _DissolveMap_ST;
float _Dissolve_Toggle;
float4 _Dissolve;
float4 _BaseMap_ST;
float _BaseMapUVRotation;
float _BaseMapUVRotationSpeed;
float4 _BaseMapMaskMapOffset;
float _MaskMapUVRotation;
float _MaskMapRotationSpeed;
float4 _MaskMapOffsetAnition;
float4 _DissolveOffsetRotateDistort;
float4 _DissolveMaskMap_TexelSize;
float4 _DissolveMaskMap_ST;
float _DissolveMask_Toggle;
float _DissolveMaskMode;
float4 _MaskMap2_TexelSize;
float4 _MaskMap2_ST;
float _Mask2_Toggle;
float4 _MaskMap3_TexelSize;
float4 _MaskMap3_ST;
float _Mask3_Toggle;
float4 _MaskMap3OffsetAnition;
float _NB_WrapFlagsLo16;
float _NB_WrapFlagsHi16;
float _MaskMapGradientCount;
float4 _MaskMapGradientFloat0;
float4 _MaskMapGradientFloat1;
float4 _MaskMapGradientFloat2;
float _MaskMap2GradientCount;
float4 _MaskMap2GradientFloat0;
float4 _MaskMap2GradientFloat1;
float4 _MaskMap2GradientFloat2;
float _MaskMap3GradientCount;
float4 _MaskMap3GradientFloat0;
float4 _MaskMap3GradientFloat1;
float4 _MaskMap3GradientFloat2;
float _AlphaAll;
float4 _ColorA;
float _BaseColorIntensityForTimeline;
float4 _BaseBackColor;
float4 _EmissionMap_TexelSize;
float4 _EmissionMap_ST;
float _EmissionEnabled;
float4 _EmissionMapUVOffset;
float _EmissionMapUVRotation;
float4 _EmissionMapColor;
float _EmissionMapColorIntensity;
float _EmissionAlphaIntensity;
float4 _ColorBlendMap_TexelSize;
float4 _ColorBlendMap_ST;
float _ColorBlendMap_Toggle;
float4 _ColorBlendMapOffset;
float4 _ColorBlendVec;
float4 _ColorBlendColor;
float _ColorBlendColorIntensity;
float4 _RampColorMap_TexelSize;
float4 _RampColorMap_ST;
float _RampColorToggle;
float _RampColorSourceMode;
float4 _RampColorMapOffset;
float4 _RampColor0;
float4 _RampColor1;
float4 _RampColor2;
float4 _RampColor3;
float4 _RampColor4;
float4 _RampColor5;
float4 _RampColorAlpha0;
float4 _RampColorAlpha1;
float4 _RampColorAlpha2;
float _RampColorCount;
float4 _RampColorBlendColor;
float _HueShift;
float _Contrast;
float4 _ContrastMidColor;
float _Saturability;
float4 _BaseMapColorRefine;
float _fresnelEnabled;
float4 _FresnelUnit;
float4 _FresnelColor;
float4 _FresnelRotation;
float4 _Dissolve_Vec2;
float4 _DissolveLineColor;
float _Dissolve_useRampMap_Toggle;
float4 _DissolveRampMap_TexelSize;
float4 _DissolveRampMap_ST;
float _DissolveRampSourceMode;
float4 _DissolveRampColor;
float _DissolveRampCount;
float4 _DissolveRampColor0;
float4 _DissolveRampColor1;
float4 _DissolveRampColor2;
float4 _DissolveRampColor3;
float4 _DissolveRampColor4;
float4 _DissolveRampColor5;
float4 _DissolveRampAlpha0;
float4 _DissolveRampAlpha1;
float4 _DissolveRampAlpha2;
float _NB_ForceNoMipFlagsLo16;
float _NB_ForceNoMipFlagsHi16;
};

// Graph Includes
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl"
#include_with_pragmas "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBGraphBaseColor.hlsl"

// -- Property used by ScenePickingPass
#ifdef SCENEPICKINGPASS
float4 _SelectionID;
#endif

// -- Properties used by SceneSelectionPass
#ifdef SCENESELECTIONPASS
int _ObjectId;
int _PassValue;
#endif

// Graph Functions
// GraphFunctions: <None>

// Custom interpolators pre vertex
/* WARNING: $splice Could not find named fragment 'CustomInterpolatorPreVertex' */

// Graph Vertex
struct VertexDescription
{
float3 Position;
float3 Normal;
float3 Tangent;
};

VertexDescription VertexDescriptionFunction(VertexDescriptionInputs IN, GraphProperties PROP)
{
VertexDescription description = (VertexDescription)0;
description.Position = IN.ObjectSpacePosition;
description.Normal = IN.ObjectSpaceNormal;
description.Tangent = IN.ObjectSpaceTangent;
return description;
}

// Custom interpolators, pre surface
#ifdef FEATURES_GRAPH_VERTEX
Varyings CustomInterpolatorPassThroughFunc(inout Varyings output, VertexDescription input)
{
return output;
}
#define CUSTOMINTERPOLATOR_VARYPASSTHROUGH_FUNC
#endif

// Graph Pixel
struct SurfaceDescription
{
float3 BaseColor;
float Alpha;
float AlphaClipThreshold;
};

SurfaceDescription SurfaceDescriptionFunction(SurfaceDescriptionInputs IN, GraphProperties PROP)
{
SurfaceDescription surface = (SurfaceDescription)0;
UnityTexture2D _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_BaseMap, sampler_BaseMap, _BaseMap_TexelSize, float4(1, 1, 0, 0), float4(0, 0, 0, 0));
float4 _UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4 = IN.uv0;
float4 _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4 = PROP._BaseMap_ST;
float _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float = PROP._BaseMapUVRotation;
float _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float = PROP._BaseMapUVRotationSpeed;
float4 _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4 = PROP._BaseMapMaskMapOffset;
float2 _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2;
NBGraphBaseUV_float(_UV_dde6e6f3492e4fa689d7f4a88f3b492b_Out_0_Vector4, _Property_7a2d908f5a2f4990ae14fd870e5a22c9_Out_0_Vector4, _Property_45764d3c363e48539c14ce1d9b8eb3bb_Out_0_Float, _Property_4c0c6ce883a14260b681ac41d0f78472_Out_0_Float, _Property_ea0189e7a35b4e44a9e5775b9d1ec406_Out_0_Vector4, _NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2);
float4 _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = SAMPLE_TEXTURE2D(_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.tex, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.samplerstate, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.GetTransformedUV(_NBGraphBaseUVCustomFunction_3a9a7297f5dc4c46a1b595a6709c6f26_Out_5_Vector2) );
if (_Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode.x > 0)
_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4 = DecodeHDRSample(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _Property_8f072da64b1f45d992849b1e47b91c14_Out_0_Texture2D.hdrDecode);
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_R_4_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.r;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_G_5_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.g;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_B_6_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.b;
float _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float = _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4.a;
float4 _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4 = PROP._Color;
float _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float = PROP._NB_Flags0Lo16;
float _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float = PROP._NB_Flags0Hi16;
float _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float = PROP._NB_Flags1Lo16;
float _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float = PROP._NB_Flags1Hi16;
float2 _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2 = PROP._NB_DistortionNoise;
float _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float = PROP._NB_DistortionIntensity;
float _Property_01827f8348b040028326054a1623cc84_Out_0_Float = PROP._NB_DistortionMode;
float _Property_87436152ca164e73877206654813b186_Out_0_Float = PROP._NB_DistortionAlphaPow;
float _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float = PROP._NB_DistortionAlphaMultiplier;
float _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float = PROP._NB_DistortionAlphaAdd;
UnityTexture2D _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap, sampler_MaskMap, _MaskMap_TexelSize, _MaskMap_ST, float4(0, 0, 0, 0));
float _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float = PROP._Mask_Toggle;
float4 _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4 = PROP._MaskMapVec;
float4 _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4 = PROP._MaskRefineVec;
float _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float = PROP._NB_ColorChannelLo16;
UnityTexture2D _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMap, sampler_DissolveMap, _DissolveMap_TexelSize, _DissolveMap_ST, float4(0, 0, 0, 0));
float _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float = PROP._Dissolve_Toggle;
float4 _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4 = PROP._Dissolve;
float _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float = PROP._MaskMapUVRotation;
float _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float = PROP._MaskMapRotationSpeed;
float4 _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4 = PROP._MaskMapOffsetAnition;
float4 _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4 = PROP._DissolveOffsetRotateDistort;
UnityTexture2D _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveMaskMap, sampler_DissolveMaskMap, _DissolveMaskMap_TexelSize, _DissolveMaskMap_ST, float4(0, 0, 0, 0));
float _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float = PROP._DissolveMask_Toggle;
float _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float = PROP._DissolveMaskMode;
UnityTexture2D _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap2, sampler_MaskMap2, _MaskMap2_TexelSize, _MaskMap2_ST, float4(0, 0, 0, 0));
float _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float = PROP._Mask2_Toggle;
UnityTexture2D _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_MaskMap3, sampler_MaskMap3, _MaskMap3_TexelSize, _MaskMap3_ST, float4(0, 0, 0, 0));
float _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float = PROP._Mask3_Toggle;
float4 _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4 = PROP._MaskMap3OffsetAnition;
float _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float = PROP._NB_WrapFlagsLo16;
float _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float = PROP._NB_WrapFlagsHi16;
float _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float = PROP._MaskMapGradientCount;
float4 _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4 = PROP._MaskMapGradientFloat0;
float4 _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4 = PROP._MaskMapGradientFloat1;
float4 _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4 = PROP._MaskMapGradientFloat2;
float _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float = PROP._MaskMap2GradientCount;
float4 _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4 = PROP._MaskMap2GradientFloat0;
float4 _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4 = PROP._MaskMap2GradientFloat1;
float4 _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4 = PROP._MaskMap2GradientFloat2;
float _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float = PROP._MaskMap3GradientCount;
float4 _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4 = PROP._MaskMap3GradientFloat0;
float4 _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4 = PROP._MaskMap3GradientFloat1;
float4 _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4 = PROP._MaskMap3GradientFloat2;
float _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float = PROP._AlphaAll;
float4 _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4 = PROP._ColorA;
float _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float = PROP._BaseColorIntensityForTimeline;
float4 _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._BaseBackColor) : PROP._BaseBackColor;
float _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean = max(0, IN.FaceSign.x);
UnityTexture2D _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_EmissionMap, sampler_EmissionMap, _EmissionMap_TexelSize, _EmissionMap_ST, float4(0, 0, 0, 0));
float _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float = PROP._EmissionEnabled;
float4 _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4 = PROP._EmissionMapUVOffset;
float _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float = PROP._EmissionMapUVRotation;
float4 _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._EmissionMapColor) : PROP._EmissionMapColor;
float _Property_10781681264d5230974041a749fa166e_Out_0_Float = PROP._EmissionMapColorIntensity;
float _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float = PROP._EmissionAlphaIntensity;
UnityTexture2D _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_ColorBlendMap, sampler_ColorBlendMap, _ColorBlendMap_TexelSize, _ColorBlendMap_ST, float4(0, 0, 0, 0));
float _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float = PROP._ColorBlendMap_Toggle;
float4 _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4 = PROP._ColorBlendMapOffset;
float4 _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4 = PROP._ColorBlendVec;
float4 _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._ColorBlendColor) : PROP._ColorBlendColor;
float _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float = PROP._ColorBlendColorIntensity;
UnityTexture2D _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_RampColorMap, sampler_RampColorMap, _RampColorMap_TexelSize, _RampColorMap_ST, float4(0, 0, 0, 0));
float _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float = PROP._RampColorToggle;
float _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float = PROP._RampColorSourceMode;
float4 _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4 = PROP._RampColorMapOffset;
float4 _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4 = PROP._RampColor0;
float4 _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4 = PROP._RampColor1;
float4 _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4 = PROP._RampColor2;
float4 _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4 = PROP._RampColor3;
float4 _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4 = PROP._RampColor4;
float4 _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4 = PROP._RampColor5;
float4 _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4 = PROP._RampColorAlpha0;
float4 _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4 = PROP._RampColorAlpha1;
float4 _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4 = PROP._RampColorAlpha2;
float _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float = PROP._RampColorCount;
float4 _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._RampColorBlendColor) : PROP._RampColorBlendColor;
float _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float = PROP._HueShift;
float _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float = PROP._Contrast;
float4 _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4 = PROP._ContrastMidColor;
float _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float = PROP._Saturability;
float4 _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4 = PROP._BaseMapColorRefine;
float _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float = PROP._fresnelEnabled;
float4 _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4 = PROP._FresnelUnit;
float4 _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._FresnelColor) : PROP._FresnelColor;
float4 _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4 = PROP._FresnelRotation;
float4 _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4 = PROP._Dissolve_Vec2;
float4 _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveLineColor) : PROP._DissolveLineColor;
float _Property_872303b3673f5db6ba39a80132854337_Out_0_Float = PROP._Dissolve_useRampMap_Toggle;
UnityTexture2D _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D = UnityBuildTexture2DStructInternal(_DissolveRampMap, sampler_DissolveRampMap, _DissolveRampMap_TexelSize, _DissolveRampMap_ST, float4(0, 0, 0, 0));
float _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float = PROP._DissolveRampSourceMode;
float4 _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4 = IsGammaSpace() ? LinearToSRGB(PROP._DissolveRampColor) : PROP._DissolveRampColor;
float _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float = PROP._DissolveRampCount;
float4 _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4 = PROP._DissolveRampColor0;
float4 _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4 = PROP._DissolveRampColor1;
float4 _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4 = PROP._DissolveRampColor2;
float4 _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4 = PROP._DissolveRampColor3;
float4 _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4 = PROP._DissolveRampColor4;
float4 _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4 = PROP._DissolveRampColor5;
float4 _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4 = PROP._DissolveRampAlpha0;
float4 _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4 = PROP._DissolveRampAlpha1;
float4 _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4 = PROP._DissolveRampAlpha2;
float _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float = PROP._NB_ForceNoMipFlagsLo16;
float _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float = PROP._NB_ForceNoMipFlagsHi16;
float4 _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4;
NBGraphBaseColor_float(_SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_RGBA_0_Vector4, _SampleTexture2D_4d248e9f5feb4a6f8c5adff6055f882c_A_7_Float, _Property_13840ad57da543e2b33275638ce1189e_Out_0_Vector4, _Property_eafd46b75a1746f093439de914a3717c_Out_0_Float, _Property_02448b2e80a0440b804602e588eb2727_Out_0_Float, _Property_52b95ce95e564cb083a7953179be1554_Out_0_Float, _Property_6abc2ac395a54d7f99af7850796b2c20_Out_0_Float, _Property_4fbc64ac55184ee8b2348b861c93db8b_Out_0_Vector2, _Property_9099f47df6d24486a9e0bb9dd8fa7cf8_Out_0_Float, _Property_01827f8348b040028326054a1623cc84_Out_0_Float, _Property_87436152ca164e73877206654813b186_Out_0_Float, _Property_9aab3b8bff1a4b39a348ae3ea124a0e3_Out_0_Float, _Property_a31f37f37774434e8b5383ecef8f5072_Out_0_Float, _Property_e1e8e8a73a5f5e1c9e969abcb9782cd2_Out_0_Texture2D, _Property_26acbca87fca52f4a5ea05d6fcf09e48_Out_0_Float, _Property_c7f5afaa32df59eb9c6b2561b57aa26f_Out_0_Vector4, _Property_6e138238299250348f63a5ee2f1f3d5b_Out_0_Vector4, _Property_20f932f599b85641aeb7c2ea908ed484_Out_0_Float, _Property_b4f86e887f26523f845f932a27414b5b_Out_0_Texture2D, _Property_a70b9f8477c75d2a98fd83c15f287a37_Out_0_Float, _Property_a05025df3a5c534f88355f30cb99d2d3_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_c4d2b9d87084415fb9b51e578a0b9080_Out_0_Float, _Property_43ed7c33980543efb0a5f6f413791461_Out_0_Float, _Property_63ba51c6efaf4d659d2b6b921e7f1a43_Out_0_Vector4, _Property_f9f92343294e499b8f4512de6aeefa5c_Out_0_Vector4, _Property_a5f2eeafb2c748ed9a1ec290960ab16f_Out_0_Texture2D, _Property_56d752220cbf4d96ab46764fc9aebb16_Out_0_Float, _Property_e1702b0dd4cf43f18d778429097ef342_Out_0_Float, IN.uv0.xy, _Property_a6ea548184d045a89325bc16be701913_Out_0_Texture2D, _Property_7c78f411c5ff4fac85800c00002c0fbc_Out_0_Float, _Property_f9394d12cb9a412e8858ece414106043_Out_0_Texture2D, _Property_7e16bb82a3584c73a47c9dcc897f62a3_Out_0_Float, _Property_282301309355467f98c2a0ca1c46538f_Out_0_Vector4, IN.uv0.xy, IN.uv0.xy, _Property_901675ce420344bb8ef7c1598f2a8c6c_Out_0_Float, _Property_84ab548e17414d57ab8ab8e23e9c9a5d_Out_0_Float, _Property_0a9b0dca2b7846869eb548347e06dfe0_Out_0_Float, _Property_bceef4027b6c4cc4b1d21c40d1e6b380_Out_0_Vector4, _Property_c8f145683c5e4bc2b543907d534d50ac_Out_0_Vector4, _Property_86555f566d7a4e47ad576dcbd5832f93_Out_0_Vector4, _Property_3e87b9d2a706453cbd9014c75528eaa0_Out_0_Float, _Property_53483bdbc2c74a8b824ea143d6eaec2b_Out_0_Vector4, _Property_4f05348fd4524abc964972190787b609_Out_0_Vector4, _Property_6235b1011ee0450c80fec0958cf7b4d4_Out_0_Vector4, _Property_a6bf239ac9f240709d42314fc1efd7b1_Out_0_Float, _Property_bcd09d9bc52b4a4f9cb57238c0902210_Out_0_Vector4, _Property_f14563d83f83427a8730d060aca57e2e_Out_0_Vector4, _Property_43d61a210ee74ffda3c292b0848511af_Out_0_Vector4, _Property_5cdf8c4f8e5f4271bf734cfe073fcc52_Out_0_Float, _Property_adbdd97beb12402b87648f77f30ab4c0_Out_0_Vector4, IN.VertexColor, _Property_442020c8e09d56679b49c301f56b94a4_Out_0_Float, _Property_b2641bfb6535514caebe85f35a335537_Out_0_Vector4, ((float) _IsFrontFace_d1919b09d5db5f54aaa1b20fe1d91dbf_Out_0_Boolean), _Property_92eefc72bf7f56fd8f8e4084e22172be_Out_0_Texture2D, _Property_318d04aaa2195ad4b539c26b2c04eeac_Out_0_Float, IN.uv0.xy, _Property_7d76134eb0065dcf88906e1e451e441f_Out_0_Vector4, _Property_3540299c49785e3c86755a5fe22db945_Out_0_Float, _Property_4af1e92a383f585dbcf0fb0884888164_Out_0_Vector4, _Property_10781681264d5230974041a749fa166e_Out_0_Float, _Property_6b0f493dcf575d0ab56773dc813aefa6_Out_0_Float, _Property_d61bfdcc9d345709b6c4e37db8d8dc9d_Out_0_Texture2D, _Property_30534193d46e557494c8f844a330b5b4_Out_0_Float, IN.uv0.xy, _Property_36317ab840af5f6db269cbc1733a86db_Out_0_Vector4, _Property_e78fc93d059558309f51829a464ff1ed_Out_0_Vector4, _Property_a0161d17445e53a18e11ae4102584287_Out_0_Vector4, _Property_aa8cec6d7536592c83454ce0965f8b85_Out_0_Float, _Property_2c26a69a61fc52a5939877dca4507b70_Out_0_Texture2D, _Property_668c759ef0f85daa97ec0fa2c458fd91_Out_0_Float, _Property_0d0fcda8bbbf5e5dadddaf843017559f_Out_0_Float, IN.uv0.xy, _Property_eb2d499a8f40574f91ca2bfbb37b0bf7_Out_0_Vector4, _Property_65576e0f99385f1fb9a7c67087c5b89d_Out_0_Vector4, _Property_55e82011a7bd54c7969e4044ab34a602_Out_0_Vector4, _Property_f5084aa30a6751de8d599e42fb5ffff5_Out_0_Vector4, _Property_8725b71298fd58698edbc87798ea15e9_Out_0_Vector4, _Property_04d0659f70de5bb8bf5972d05a3b68c8_Out_0_Vector4, _Property_4989a100e056527b92055a3c516a4eab_Out_0_Vector4, _Property_77bf5e95cff652cdaaa6bf93adeb0f93_Out_0_Vector4, _Property_c5d14f129a11542581793506ad8ba24e_Out_0_Vector4, _Property_e84364b4aa05540ebb986ab49893b436_Out_0_Vector4, _Property_7f00ce17ce115d2bb969973b132fe3e8_Out_0_Float, _Property_89e65c225052579ea3ac6095a234f65a_Out_0_Vector4, _Property_4750fb93d1d1562bad31b25dec3f8b25_Out_0_Float, _Property_5e6a32f15bf05438b9cc108706ad0625_Out_0_Float, _Property_866cffb762935a229d1b940e1f8b905c_Out_0_Vector4, _Property_f97ecb43f95c5e37b841c32f67fa546e_Out_0_Float, _Property_713b0ac7fdd85eb2a23076a581e94638_Out_0_Vector4, _Property_2fd1783a3bdc52f88effab68b88e0a47_Out_0_Float, _Property_760680a31d7b57b3a03b703fedd7dea7_Out_0_Vector4, _Property_2e33a988d6ea5eaea31eb783d2cb2026_Out_0_Vector4, _Property_990aa20b0fbe58bab561e7a26ecc62ad_Out_0_Vector4, IN.WorldSpaceNormal, IN.WorldSpaceViewDirection, _Property_e5767a3f300954768906d034fee505b2_Out_0_Vector4, _Property_28013c8ed2865dbba415684e772fbe2f_Out_0_Vector4, _Property_872303b3673f5db6ba39a80132854337_Out_0_Float, _Property_f712ace2c0ec59aca6e4ea56a5dc642b_Out_0_Texture2D, _Property_3f274a4912255dc2aa6e18641c408bd6_Out_0_Float, _Property_2d934283df7757faadf21ff2aa713bb4_Out_0_Vector4, _Property_d2afb0df25d55430acab801c8a3dbfde_Out_0_Float, _Property_0dec3b42d61b5e7c862c4ca295f9e208_Out_0_Vector4, _Property_4b091596ce61549b96d0e88967383f48_Out_0_Vector4, _Property_e246b4e0fa405aca8b55e192c06587a0_Out_0_Vector4, _Property_7a5d7978834d5d4eb9428c0a196dfbd3_Out_0_Vector4, _Property_6ab07b2800785722806fc80f0a180a5e_Out_0_Vector4, _Property_5250e3a06c0252d6a6bb9743ea2f0ac1_Out_0_Vector4, _Property_64999d5c415b5a73b4a0c204bcf29377_Out_0_Vector4, _Property_a934aa24a47f5da2992d3e468dbd374d_Out_0_Vector4, _Property_629063539c105cb3a2e8d3eade7eefb1_Out_0_Vector4, _Property_fc9eb8a77e24500ab5421051111d6fda_Out_0_Float, _Property_6311ff30de835a0da66e70c41e5eb4a9_Out_0_Float, _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4);
float _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float = _NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.w;
surface.BaseColor = (_NBGraphBaseColorCustomFunction_f712bc264a1c40848edc2dd476a4cada_Out_3_Vector4.xyz);
surface.Alpha = _Swizzle_52d10f3207ae43dc9038120fea622ca3_Out_1_Float;
surface.AlphaClipThreshold = float(0.5);
return surface;
}

// --------------------------------------------------
// Build Graph Inputs
#ifdef HAVE_VFX_MODIFICATION
#define VFX_SRP_ATTRIBUTES Attributes
#define VFX_SRP_VARYINGS Varyings
#define VFX_SRP_SURFACE_INPUTS SurfaceDescriptionInputs
#endif
//VFXDefineSpace splice
    #define VFX_WORLD_SPACE 1
    
    //VFXDefines splice
    #define VFX_USE_POSITION_CURRENT 1
    #define VFX_USE_ALIVE_CURRENT 1
    #define VFX_USE_PIVOTX_CURRENT 1
    #define VFX_USE_PIVOTY_CURRENT 1
    #define VFX_USE_PIVOTZ_CURRENT 1
    #define VFX_USE_SIZE_CURRENT 1
    #define VFX_USE_SCALEX_CURRENT 1
    #define VFX_USE_SCALEY_CURRENT 1
    #define VFX_USE_SCALEZ_CURRENT 1
    #define VFX_USE_AXISX_CURRENT 1
    #define VFX_USE_AXISY_CURRENT 1
    #define VFX_USE_AXISZ_CURRENT 1
    #define VFX_USE_ANGLEX_CURRENT 1
    #define VFX_USE_ANGLEY_CURRENT 1
    #define VFX_USE_ANGLEZ_CURRENT 1
    #define RAW_CAPACITY 1u
    #define USE_BASE_COLOR_MAP 1
    #define USE_BASE_COLOR_MAP_COLOR 1
    #define USE_BASE_COLOR_MAP_ALPHA 1
    #define VFX_COLORMAPPING_DEFAULT 1
    #define IS_TRANSPARENT_PARTICLE 1
    #define VFX_BLENDMODE_ALPHA 1
    #define VFX_HAS_INDIRECT_DRAW 1
    #define VFX_USE_INSTANCING 1
    #define VFX_INSTANCING_FIXED_SIZE 1
    #pragma multi_compile_instancing
    
    #define NULL_GEOMETRY_INPUT defined(HAVE_VFX_PLANAR_PRIMITIVE)
    
    #if HAS_STRIPS
    #define HAS_STRIPS_DATA 1
    #endif
    
    // Explicitly defined here for now (similar to how it was done in the previous VFX code-gen)
    #define HAS_VFX_ATTRIBUTES 1
    
    // VFX has some internal functions for strips or CustomBlockHLSL that assume the generically named "VFXAttributes" struct as input.
    // For now, override it. TODO: Improve the generic struct name for VFX shader library.
    #define VFXAttributes InternalAttributesElement
    
    #define VFX_NEEDS_COLOR_INTERPOLATOR (VFX_USE_COLOR_CURRENT || VFX_USE_ALPHA_CURRENT)
    #if HAS_STRIPS
    #define VFX_OPTIONAL_INTERPOLATION
    #else//
    #define VFX_OPTIONAL_INTERPOLATION nointerpolation
    #endif
    
    ByteAddressBuffer attributeBuffer;
    
    #if VFX_HAS_INDIRECT_DRAW
    StructuredBuffer<uint> indirectBuffer;
    #endif
    
    #if USE_DEAD_LIST_COUNT
    StructuredBuffer<uint> deadList;
    #endif
    
    #if HAS_STRIPS_DATA
    StructuredBuffer<uint> stripDataBuffer;
    #endif
    
    #if VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS
    ByteAddressBuffer elementToVFXBufferPrevious;
    #endif
    
    CBUFFER_START(outputParams)
        float4 instancingConstants;
        float3 cameraXRSettings;
    CBUFFER_END
    
    UNITY_INSTANCING_BUFFER_START(PerInstance)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceIndex)
    UNITY_DEFINE_INSTANCED_PROP(float, _InstanceActiveIndex)
    UNITY_INSTANCING_BUFFER_END(PerInstance)
    
    // Helper macros to always use a valid instanceID
    #if defined(UNITY_STEREO_INSTANCING_ENABLED)
        #define VFX_DECLARE_INSTANCE_ID     UNITY_VERTEX_INPUT_INSTANCE_ID
        #define VFX_GET_INSTANCE_ID(i)      unity_InstanceID
    #else
        #define VFX_DECLARE_INSTANCE_ID     uint instanceID : SV_InstanceID;
        #define VFX_GET_INSTANCE_ID(i)      input.instanceID
    #endif
    
    // These are supposed to be passed as a instanced constant property (unity_SpriteFlipArray) for sprites, but it doesn't work for VFX Shadergraph mesh outputs
    // because the instancing constant arrays (UNITY_DEFINE_INSTANCED_PROP...) are used for per-effect instancing in VFX, not per-particle instancing.
    // In any case, the value passed for VFX is always (1,1) currently, and not user-modifiable, so no need to get it from a constant buffer.
    #define unity_SpriteProps float4(1,1,1,1)
    #ifdef unity_SpriteColor
    #undef unity_SpriteColor
    #endif
    #define unity_SpriteColor float4(1,1,1,1)
    
    
    
    
    #include "Packages/com.unity.render-pipelines.universal/Runtime/VFXGraph/Shaders/VFXCommon.hlsl"
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommon.hlsl"
    
    #include "Packages/com.unity.visualeffectgraph/Shaders/VFXCommonOutput.hlsl"
    
    ByteAddressBuffer graphValuesBuffer;
    
    
    
    
    
    
    
    
    
    struct AttributesElement
    {
        uint index;
        uint instanceIndex;
        uint instanceActiveIndex;
        // Internal attributes sub-struct used by VFX code-gen property mapping.
        InternalAttributesElement attributes;
    
        // Additional attribute information for particle strips.
    #if HAS_STRIPS_DATA
        uint relativeIndexInStrip;
        StripData stripData;
    #endif
    
        // Additional parameter information for motion vectors
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint currentFrameIndex;
    #endif
    };
    
    bool ShouldCullElement(uint index, uint vfxInstanceIndex, uint nbMax)
    {
        uint deadCount = 0;
    #if USE_DEAD_LIST_COUNT
        deadCount = deadList[vfxInstanceIndex];
    #endif
    
    #if HAS_STRIPS && !VFX_HAS_INDIRECT_DRAW
        // We render one particle less for each strip in this case
        nbMax -= STRIP_COUNT;
    #endif
    
        return (index >= nbMax - deadCount);
    }
    
    float3 GetElementSize(InternalAttributesElement attributes)
    {
        float3 size3 = float3(attributes.size,attributes.size,attributes.size);
    
        // TODO: Currently these do not get defined/generated.
    #if VFX_USE_SCALEX_CURRENT
        size3.x *= attributes.scaleX;
    #endif
    #if VFX_USE_SCALEY_CURRENT
        size3.y *= attributes.scaleY;
    #endif
    #if VFX_USE_SCALEZ_CURRENT
        size3.z *= attributes.scaleZ;
    #endif
    
    #if HAS_STRIPS
         // Add an epsilon so that size is never 0 for strips
         size3 += size3 < 0.0f ? -VFX_EPSILON : VFX_EPSILON;
    #endif
    
        return size3;
    }
    
    float3 GetElementSizeRT(InternalAttributesElement attributes
    #if VFX_USE_GRAPH_VALUES
        , GraphValues graphValues
    #endif
    )
    {
        float3 size3 = GetElementSize(attributes);
    
        float3 rtScale = float3(1,1,1);
    
    #if VFX_USE_RT_CUSTOM_SCALE
        
        rtScale = float3(rayTracedScaling,1.0f);
    #else
        #ifdef VFX_RT_DEFAULT_SCALE
            rtScale = VFX_RT_DEFAULT_SCALE;
        #endif
    #endif
    
        size3 *= rtScale;
        return size3;
    }
    
    #if HAS_STRIPS
    float3 GetParticlePosition(uint index, uint instanceIndex)
    {
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        // Here we have to explicitly splice in the position (ShaderGraph splice system lacks regex support etc. :(, unlike VFX's).
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    
    
        return attributes.position;
    }
    
    float3 GetStripTangent(float3 currentPos, uint instanceIndex, uint relativeIndex, const StripData stripData)
    {
        float3 prevTangent = (float3)0.0f;
        if (relativeIndex > 0)
        {
            uint prevIndex = GetParticleIndex(relativeIndex - 1, stripData);
            float3 tangent = currentPos - GetParticlePosition(prevIndex, instanceIndex);
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                prevTangent = tangent * rsqrt(sqrLength);
        }
    
        float3 nextTangent = (float3)0.0f;
        if (relativeIndex + 1 < stripData.nextIndex)
        {
            uint nextIndex = GetParticleIndex(relativeIndex + 1, stripData);
            float3 tangent = GetParticlePosition(nextIndex, instanceIndex) - currentPos;
            float sqrLength = dot(tangent, tangent);
            if (sqrLength > VFX_EPSILON * VFX_EPSILON)
                nextTangent = tangent * rsqrt(sqrLength);
        }
    
        return VFXSafeNormalize(prevTangent + nextTangent);
    }
    #endif
    
    void GetElementData(inout AttributesElement element)
    {
        uint index = element.index;
        uint instanceIndex = element.instanceIndex;
        uint instanceActiveIndex = element.instanceActiveIndex;
    #if VFX_USE_GRAPH_VALUES
        
    #endif
    
        InternalAttributesElement attributes;
        ZERO_INITIALIZE(InternalAttributesElement, attributes);
    
        attributes.position = asfloat(attributeBuffer.Load3(((instanceIndex * 0x24) + (index * 0x4 + 0x4)) << 2));
    attributes.alive = (attributeBuffer.Load(((instanceIndex * 0x24) + (index * 0x4 + 0x7)) << 2));
    attributes.pivotX = (float)0;
    attributes.pivotY = (float)0;
    attributes.pivotZ = (float)0;
    attributes.size = (float)0.100000001;
    attributes.scaleX = (float)1;
    attributes.scaleY = (float)1;
    attributes.scaleZ = (float)1;
    attributes.axisX = float3(1, 0, 0);
    attributes.axisY = float3(0, 1, 0);
    attributes.axisZ = float3(0, 0, 1);
    attributes.angleX = (float)0;
    attributes.angleY = (float)0;
    attributes.angleZ = (float)0;
    
    
        #if HAS_STRIPS_DATA
        const StripData stripData = element.stripData;
        const uint relativeIndexInStrip = element.relativeIndexInStrip;
        InitStripAttributes(index, attributes, element.stripData);
        #endif
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        
        element.currentFrameIndex = currentFrameIndex;
    #endif
    
    #if !VFX_HAS_INDIRECT_DRAW && !HAS_STRIPS
        if (attributes.alive)
    #endif
        {
        
        }
    
        element.attributes = attributes;
    }
    
    // Configure the output type-spcific mesh definition and index calculation for the rest of the element data.
    // Output Type: Mesh
        
        bool GetMeshAndElementIndex(inout VFX_SRP_ATTRIBUTES input, inout AttributesElement element)
        {
            uint index = VFX_GET_INSTANCE_ID(input);
        
            uint instanceIndex, instanceActiveIndex, instanceCurrentIndex;
        index = VFXInitInstancing(index, instanceIndex, instanceActiveIndex, instanceCurrentIndex);
        
            #ifdef UNITY_INSTANCING_ENABLED
            input.instanceID = unity_InstanceID;
            #endif
            struct ContextData
        {
            uint maxParticleCount;
            uint systemSeed;
            uint initSpawnIndex;
        };
        ContextData contextData;
        uint4 rawContextData = graphValuesBuffer.Load4(instanceActiveIndex * 160);
        contextData.maxParticleCount = rawContextData.x;
        contextData.systemSeed = rawContextData.y;
        contextData.initSpawnIndex = rawContextData.z;
        
            uint systemSeed = contextData.systemSeed;
            uint nbMax = contextData.maxParticleCount;
            if (ShouldCullElement(index, instanceIndex, nbMax))
                return false;
        
            #if VFX_HAS_INDIRECT_DRAW
            index = indirectBuffer[VFXGetIndirectBufferIndex(index, instanceActiveIndex)];
            #endif
        
            #if HAS_STRIPS_DATA
                StripData stripData = GetStripDataFromParticleIndex(index, instanceIndex);
                element.relativeIndexInStrip = GetRelativeIndex(index, stripData);
                element.stripData = stripData;
            #endif
        
            element.index = index;
            element.instanceIndex = instanceIndex;
            element.instanceActiveIndex = instanceActiveIndex;
        
            // Mesh requires no preliminary configuration.
            return true;
        }
        
    #if !defined(SHADER_STAGE_RAY_TRACING)
    
    // Loads the element-specific attribute data, as well as fills any interpolator.
    bool GetInterpolatorAndElementData(inout VFX_SRP_ATTRIBUTES input, inout VFX_SRP_VARYINGS output, inout AttributesElement element)
    {
        GetElementData(element);
        #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
        #endif
        InternalAttributesElement attributes = element.attributes;
    
        #if !HAS_STRIPS
        if (!attributes.alive)
            return false;
        #endif
        #ifdef ATTRIBUTES_NEED_NORMAL
        float3 size3 = GetElementSize(element.attributes);
        float normalFlip = (size3.x * size3.y * size3.z) < 0 ? -1 : 1;
        input.normalOS *= normalFlip;
        #endif
        
    
    
        return true;
    }
    
    // Reconstruct the VFX/World to Element matrix provided by interpolator.
    void BuildWorldToElement(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        worldToElement[0] = input.worldToElement0;
        worldToElement[1] = input.worldToElement1;
        worldToElement[2] = input.worldToElement2;
        worldToElement[3] = float4(0,0,0,1);
    #endif
    }
    
    void BuildElementToWorld(VFX_SRP_VARYINGS input)
    {
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        elementToWorld[0] = input.elementToWorld0;
        elementToWorld[1] = input.elementToWorld1;
        elementToWorld[2] = input.elementToWorld2;
        elementToWorld[3] = float4(0,0,0,1);
    #endif
    }
    
    void SetupVFXMatrices(AttributesElement element, inout VFX_SRP_VARYINGS output)
    {
        // Due to a very stubborn compiler bug we cannot refer directly to the redefined UNITY_MATRIX_M / UNITY_MATRIX_I_M here, due to a rare case where the matrix alias
        // is potentially still the constant object matrices (thus complaining about l-value specifying const object). Note even judicious use of preprocessors seems to
        // fix it, so we instead we directly refer to the static matrices.
    
        // Element -> World
        elementToWorld = GetElementToVFXMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
            float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        elementToWorld = mul(GetSGVFXUnityObjectToWorld(), elementToWorld);
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        elementToWorld = ApplyCameraTranslationToMatrix(elementToWorld);
    #endif
    
        // World -> Element
        worldToElement = GetVFXToElementMatrix(
            element.attributes.axisX,
            element.attributes.axisY,
            element.attributes.axisZ,
            float3(element.attributes.angleX,element.attributes.angleY,element.attributes.angleZ),
            float3(element.attributes.pivotX,element.attributes.pivotY,element.attributes.pivotZ),
            GetElementSize(element.attributes),
            element.attributes.position
        );
    
    #if VFX_LOCAL_SPACE
        worldToElement = mul(worldToElement,GetSGVFXUnityWorldToObject());
    #elif !defined(VFX_HAS_PICKING_MATRIX_CORRECTION)
        worldToElement = ApplyCameraTranslationToInverseMatrix(worldToElement);
    #endif
    
        // Pack matrices into interpolator if requested by any node.
    #ifdef VARYINGS_NEED_ELEMENT_TO_WORLD
        output.elementToWorld0 = elementToWorld[0];
        output.elementToWorld1 = elementToWorld[1];
        output.elementToWorld2 = elementToWorld[2];
    #endif
    
    #ifdef VARYINGS_NEED_WORLD_TO_ELEMENT
        output.worldToElement0 = worldToElement[0];
        output.worldToElement1 = worldToElement[1];
        output.worldToElement2 = worldToElement[2];
    #endif
    }
    #endif
    
    float4 VFXGetPreviousClipPosition(VFX_SRP_ATTRIBUTES input, AttributesElement element, float4 cPositionFallback)
    {
        float4 cPreviousPos = cPositionFallback;
    
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint vertexId = input.vertexID;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            cPreviousPos = VFXGetPreviousClipPosition(elementToVFXBaseIndex, vertexId);
        }
    #endif
    
        return cPreviousPos;
    }
    
    VFX_SRP_ATTRIBUTES VFXTransformMeshToPreviousElement(VFX_SRP_ATTRIBUTES input, AttributesElement element)
    {
    #if (VFX_FEATURE_MOTION_VECTORS_FORWARD || USE_MOTION_VECTORS_PASS)
        uint elementIndex = element.index;
        uint elementToVFXBaseIndex;
        if (TryGetElementToVFXBaseIndex(elementIndex, element.instanceIndex, elementToVFXBaseIndex, element.currentFrameIndex))
        {
            float4x4 previousElementToVFX = VFXGetPreviousElementToVFX(elementToVFXBaseIndex);
            input.positionOS = mul(previousElementToVFX, float4(input.positionOS, 1.0f)).xyz;
        }
        else
    #endif//WRITE_MOTION_VECTOR_IN_FORWARD || USE_MOTION_VECTORS_PASS
        {
            float4x4 elementToVFXMatrix = GetElementToVFXMatrix(
                element.attributes.axisX,
                element.attributes.axisY,
                element.attributes.axisZ,
                float3(element.attributes.angleX, element.attributes.angleY, element.attributes.angleZ),
                float3(element.attributes.pivotX, element.attributes.pivotY, element.attributes.pivotZ),
                GetElementSize(element.attributes),
                element.attributes.position);
            input.positionOS = mul(elementToVFXMatrix, float4(input.positionOS, 1.0f)).xyz;
        }
    
        return input;
    }
    
    // Vertex + Pixel Graph Properties Generation
    void GetElementVertexProperties(AttributesElement element, inout GraphProperties properties)
    {
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = element.instanceActiveIndex;
        
    #endif
        InternalAttributesElement attributes = element.attributes;
        
    
    }
    
    void GetElementPixelProperties(VFX_SRP_SURFACE_INPUTS fragInputs, inout GraphProperties properties)
    {
        properties._Color = fragInputs._Color;
    properties._NB_DistortionNoise = fragInputs._NB_DistortionNoise;
    properties._NB_DistortionIntensity = fragInputs._NB_DistortionIntensity;
    properties._NB_DistortionMode = fragInputs._NB_DistortionMode;
    properties._NB_Flags0Lo16 = fragInputs._NB_Flags0Lo16;
    properties._NB_Flags0Hi16 = fragInputs._NB_Flags0Hi16;
    properties._NB_Flags1Lo16 = fragInputs._NB_Flags1Lo16;
    properties._NB_Flags1Hi16 = fragInputs._NB_Flags1Hi16;
    properties._NB_DistortionAlphaPow = fragInputs._NB_DistortionAlphaPow;
    properties._NB_DistortionAlphaMultiplier = fragInputs._NB_DistortionAlphaMultiplier;
    properties._NB_DistortionAlphaAdd = fragInputs._NB_DistortionAlphaAdd;
    properties._Mask_Toggle = fragInputs._Mask_Toggle;
    properties._MaskMapVec = fragInputs._MaskMapVec;
    properties._MaskRefineVec = fragInputs._MaskRefineVec;
    properties._NB_ColorChannelLo16 = fragInputs._NB_ColorChannelLo16;
    properties._BaseMap_ST = fragInputs._BaseMap_ST;
    properties._BaseMapUVRotation = fragInputs._BaseMapUVRotation;
    properties._BaseMapUVRotationSpeed = fragInputs._BaseMapUVRotationSpeed;
    properties._BaseMapMaskMapOffset = fragInputs._BaseMapMaskMapOffset;
    properties._MaskMapUVRotation = fragInputs._MaskMapUVRotation;
    properties._MaskMapRotationSpeed = fragInputs._MaskMapRotationSpeed;
    properties._MaskMapOffsetAnition = fragInputs._MaskMapOffsetAnition;
    properties._DissolveOffsetRotateDistort = fragInputs._DissolveOffsetRotateDistort;
    properties._DissolveMask_Toggle = fragInputs._DissolveMask_Toggle;
    properties._DissolveMaskMode = fragInputs._DissolveMaskMode;
    properties._Mask2_Toggle = fragInputs._Mask2_Toggle;
    properties._Mask3_Toggle = fragInputs._Mask3_Toggle;
    properties._MaskMap3OffsetAnition = fragInputs._MaskMap3OffsetAnition;
    properties._NB_WrapFlagsLo16 = fragInputs._NB_WrapFlagsLo16;
    properties._NB_WrapFlagsHi16 = fragInputs._NB_WrapFlagsHi16;
    properties._MaskMapGradientCount = fragInputs._MaskMapGradientCount;
    properties._MaskMapGradientFloat0 = fragInputs._MaskMapGradientFloat0;
    properties._MaskMapGradientFloat1 = fragInputs._MaskMapGradientFloat1;
    properties._MaskMapGradientFloat2 = fragInputs._MaskMapGradientFloat2;
    properties._MaskMap2GradientCount = fragInputs._MaskMap2GradientCount;
    properties._MaskMap2GradientFloat0 = fragInputs._MaskMap2GradientFloat0;
    properties._MaskMap2GradientFloat1 = fragInputs._MaskMap2GradientFloat1;
    properties._MaskMap2GradientFloat2 = fragInputs._MaskMap2GradientFloat2;
    properties._MaskMap3GradientCount = fragInputs._MaskMap3GradientCount;
    properties._MaskMap3GradientFloat0 = fragInputs._MaskMap3GradientFloat0;
    properties._MaskMap3GradientFloat1 = fragInputs._MaskMap3GradientFloat1;
    properties._MaskMap3GradientFloat2 = fragInputs._MaskMap3GradientFloat2;
    properties._AlphaAll = fragInputs._AlphaAll;
    properties._ColorA = fragInputs._ColorA;
    properties._BaseColorIntensityForTimeline = fragInputs._BaseColorIntensityForTimeline;
    properties._fresnelEnabled = fragInputs._fresnelEnabled;
    properties._FresnelUnit = fragInputs._FresnelUnit;
    properties._FresnelColor = fragInputs._FresnelColor;
    properties._FresnelRotation = fragInputs._FresnelRotation;
    properties._Dissolve_Vec2 = fragInputs._Dissolve_Vec2;
    properties._DissolveLineColor = fragInputs._DissolveLineColor;
    properties._Dissolve_useRampMap_Toggle = fragInputs._Dissolve_useRampMap_Toggle;
    properties._DissolveRampSourceMode = fragInputs._DissolveRampSourceMode;
    properties._DissolveRampColor = fragInputs._DissolveRampColor;
    properties._DissolveRampCount = fragInputs._DissolveRampCount;
    properties._DissolveRampColor0 = fragInputs._DissolveRampColor0;
    properties._DissolveRampColor1 = fragInputs._DissolveRampColor1;
    properties._DissolveRampColor2 = fragInputs._DissolveRampColor2;
    properties._DissolveRampColor3 = fragInputs._DissolveRampColor3;
    properties._DissolveRampColor4 = fragInputs._DissolveRampColor4;
    properties._DissolveRampColor5 = fragInputs._DissolveRampColor5;
    properties._DissolveRampAlpha0 = fragInputs._DissolveRampAlpha0;
    properties._DissolveRampAlpha1 = fragInputs._DissolveRampAlpha1;
    properties._DissolveRampAlpha2 = fragInputs._DissolveRampAlpha2;
    properties._NB_ForceNoMipFlagsLo16 = fragInputs._NB_ForceNoMipFlagsLo16;
    properties._NB_ForceNoMipFlagsHi16 = fragInputs._NB_ForceNoMipFlagsHi16;
    properties._Dissolve_Toggle = fragInputs._Dissolve_Toggle;
    properties._Dissolve = fragInputs._Dissolve;
    properties._BaseBackColor = fragInputs._BaseBackColor;
    properties._EmissionEnabled = fragInputs._EmissionEnabled;
    properties._EmissionMapUVOffset = fragInputs._EmissionMapUVOffset;
    properties._EmissionMapUVRotation = fragInputs._EmissionMapUVRotation;
    properties._EmissionMapColor = fragInputs._EmissionMapColor;
    properties._EmissionMapColorIntensity = fragInputs._EmissionMapColorIntensity;
    properties._EmissionAlphaIntensity = fragInputs._EmissionAlphaIntensity;
    properties._ColorBlendMap_Toggle = fragInputs._ColorBlendMap_Toggle;
    properties._ColorBlendMapOffset = fragInputs._ColorBlendMapOffset;
    properties._ColorBlendVec = fragInputs._ColorBlendVec;
    properties._ColorBlendColor = fragInputs._ColorBlendColor;
    properties._ColorBlendColorIntensity = fragInputs._ColorBlendColorIntensity;
    properties._RampColorToggle = fragInputs._RampColorToggle;
    properties._RampColorSourceMode = fragInputs._RampColorSourceMode;
    properties._RampColorMapOffset = fragInputs._RampColorMapOffset;
    properties._RampColor0 = fragInputs._RampColor0;
    properties._RampColor1 = fragInputs._RampColor1;
    properties._RampColor2 = fragInputs._RampColor2;
    properties._RampColor3 = fragInputs._RampColor3;
    properties._RampColor4 = fragInputs._RampColor4;
    properties._RampColor5 = fragInputs._RampColor5;
    properties._RampColorAlpha0 = fragInputs._RampColorAlpha0;
    properties._RampColorAlpha1 = fragInputs._RampColorAlpha1;
    properties._RampColorAlpha2 = fragInputs._RampColorAlpha2;
    properties._RampColorCount = fragInputs._RampColorCount;
    properties._RampColorBlendColor = fragInputs._RampColorBlendColor;
    properties._HueShift = fragInputs._HueShift;
    properties._Contrast = fragInputs._Contrast;
    properties._ContrastMidColor = fragInputs._ContrastMidColor;
    properties._Saturability = fragInputs._Saturability;
    properties._BaseMapColorRefine = fragInputs._BaseMapColorRefine;
    
    }
    VertexDescriptionInputs BuildVertexDescriptionInputs(Attributes input)
    {
        VertexDescriptionInputs output;
        ZERO_INITIALIZE(VertexDescriptionInputs, output);
    
        output.ObjectSpaceNormal =                          input.normalOS;
        output.ObjectSpaceTangent =                         input.tangentOS.xyz;
        output.ObjectSpacePosition =                        input.positionOS;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    
        return output;
    }
    SurfaceDescriptionInputs BuildSurfaceDescriptionInputs(Varyings input)
    {
        SurfaceDescriptionInputs output;
        ZERO_INITIALIZE(SurfaceDescriptionInputs, output);
    
    #ifdef HAVE_VFX_MODIFICATION
    #if VFX_USE_GRAPH_VALUES
        uint instanceActiveIndex = asuint(UNITY_ACCESS_INSTANCED_PROP(PerInstance, _InstanceActiveIndex));
        
    #endif
        output._Color = float4(1, 1, 1, 0.666666687);
    output._NB_DistortionNoise = float2(0.25, 0);
    output._NB_DistortionIntensity = (float)0.25;
    output._NB_DistortionMode = (float)0;
    output._NB_Flags0Lo16 = (float)0;
    output._NB_Flags0Hi16 = (float)0;
    output._NB_Flags1Lo16 = (float)0;
    output._NB_Flags1Hi16 = (float)0;
    output._NB_DistortionAlphaPow = (float)1;
    output._NB_DistortionAlphaMultiplier = (float)1;
    output._NB_DistortionAlphaAdd = (float)0;
    output._Mask_Toggle = (float)0;
    output._MaskMapVec = float4(1, 0, 0, 0);
    output._MaskRefineVec = float4(1, 1, 0, 0);
    output._NB_ColorChannelLo16 = (float)3;
    output._BaseMap_ST = float4(1, 1, 0, 0);
    output._BaseMapUVRotation = (float)0;
    output._BaseMapUVRotationSpeed = (float)0;
    output._BaseMapMaskMapOffset = float4(0, 0, 0, 0);
    output._MaskMapUVRotation = (float)0;
    output._MaskMapRotationSpeed = (float)0;
    output._MaskMapOffsetAnition = float4(0, 0, 0, 0);
    output._DissolveOffsetRotateDistort = float4(0, 0, 0, 0);
    output._DissolveMask_Toggle = (float)0;
    output._DissolveMaskMode = (float)0;
    output._Mask2_Toggle = (float)0;
    output._Mask3_Toggle = (float)0;
    output._MaskMap3OffsetAnition = float4(0, 0, 0, 0);
    output._NB_WrapFlagsLo16 = (float)0;
    output._NB_WrapFlagsHi16 = (float)0;
    output._MaskMapGradientCount = (float)2;
    output._MaskMapGradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMapGradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMapGradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap2GradientCount = (float)2;
    output._MaskMap2GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap2GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap2GradientFloat2 = float4(1, 0, 1, 1);
    output._MaskMap3GradientCount = (float)2;
    output._MaskMap3GradientFloat0 = float4(0, 0, 1, 1);
    output._MaskMap3GradientFloat1 = float4(1, 0, 1, 1);
    output._MaskMap3GradientFloat2 = float4(1, 0, 1, 1);
    output._AlphaAll = (float)1;
    output._ColorA = float4(1, 1, 1, 1);
    output._BaseColorIntensityForTimeline = (float)1;
    output._fresnelEnabled = (float)0;
    output._FresnelUnit = float4(0, 0.5, 1, 0.5);
    output._FresnelColor = float4(1, 1, 1, 1);
    output._FresnelRotation = float4(0, 0, 0, 0.5);
    output._Dissolve_Vec2 = float4(0.200000003, 0.100000001, 0, 0);
    output._DissolveLineColor = float4(1, 0, 0, 1);
    output._Dissolve_useRampMap_Toggle = (float)1;
    output._DissolveRampSourceMode = (float)1;
    output._DissolveRampColor = float4(1, 1, 1, 1);
    output._DissolveRampCount = (float)131074;
    output._DissolveRampColor0 = float4(0, 0, 1, 0);
    output._DissolveRampColor1 = float4(0, 0, 1, 1);
    output._DissolveRampColor2 = float4(1, 1, 1, 1);
    output._DissolveRampColor3 = float4(1, 1, 1, 1);
    output._DissolveRampColor4 = float4(1, 1, 1, 1);
    output._DissolveRampColor5 = float4(1, 1, 1, 1);
    output._DissolveRampAlpha0 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha1 = float4(1, 0, 1, 1);
    output._DissolveRampAlpha2 = float4(1, 0, 1, 1);
    output._NB_ForceNoMipFlagsLo16 = (float)0;
    output._NB_ForceNoMipFlagsHi16 = (float)0;
    output._Dissolve_Toggle = (float)1;
    output._Dissolve = float4(0.5, 1, 1, 0.100000001);
    output._BaseBackColor = float4(1, 1, 1, 1);
    output._EmissionEnabled = (float)0;
    output._EmissionMapUVOffset = float4(0, 0, 0, 0);
    output._EmissionMapUVRotation = (float)0;
    output._EmissionMapColor = float4(1, 1, 1, 1);
    output._EmissionMapColorIntensity = (float)1;
    output._EmissionAlphaIntensity = (float)1;
    output._ColorBlendMap_Toggle = (float)0;
    output._ColorBlendMapOffset = float4(0, 0, 0, 0);
    output._ColorBlendVec = float4(0, 0, 1, 0);
    output._ColorBlendColor = float4(1, 1, 1, 1);
    output._ColorBlendColorIntensity = (float)1;
    output._RampColorToggle = (float)0;
    output._RampColorSourceMode = (float)0;
    output._RampColorMapOffset = float4(0, 0, 0, 0);
    output._RampColor0 = float4(0, 0, 0, 0);
    output._RampColor1 = float4(1, 0, 0, 1);
    output._RampColor2 = float4(1, 1, 1, 1);
    output._RampColor3 = float4(1, 1, 1, 1);
    output._RampColor4 = float4(1, 1, 1, 1);
    output._RampColor5 = float4(1, 1, 1, 1);
    output._RampColorAlpha0 = float4(1, 0, 1, 1);
    output._RampColorAlpha1 = float4(1, 0, 1, 1);
    output._RampColorAlpha2 = float4(1, 0, 1, 1);
    output._RampColorCount = (float)131074;
    output._RampColorBlendColor = float4(1, 1, 1, 1);
    output._HueShift = (float)0;
    output._Contrast = (float)1;
    output._ContrastMidColor = float4(0.5, 0.5, 0.5, 1);
    output._Saturability = (float)0;
    output._BaseMapColorRefine = float4(1, 1, 2, 0.5);
    
    
        BuildElementToWorld(input);
        BuildWorldToElement(input);
    #endif
    
        
    
        // must use interpolated tangent, bitangent and normal before they are normalized in the pixel shader.
        float3 unnormalizedNormalWS = input.normalWS;
        const float renormFactor = 1.0 / length(unnormalizedNormalWS);
    
    
        output.WorldSpaceNormal = renormFactor * input.normalWS.xyz;      // we want a unit length Normal Vector node in shader graph
    
    
        output.WorldSpaceViewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
    
        #if UNITY_UV_STARTS_AT_TOP
        #else
        #endif
    
    
        output.uv0 = input.texCoord0;
        output.VertexColor = input.color;
    #if UNITY_ANY_INSTANCING_ENABLED
    #else // TODO: XR support for procedural instancing because in this case UNITY_ANY_INSTANCING_ENABLED is not defined and instanceID is incorrect.
    #endif
    #if defined(SHADER_STAGE_FRAGMENT) && defined(VARYINGS_NEED_CULLFACE)
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN output.FaceSign =                    IS_FRONT_VFACE(input.cullFace, true, false);
    #else
    #define BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #endif
        BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    #undef BUILD_SURFACE_DESCRIPTION_INPUTS_OUTPUT_FACESIGN
    
            return output;
    }
    
// --------------------------------------------------
// Main

#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/Varyings.hlsl"
#include "Packages/com.unity.render-pipelines.universal/Editor/ShaderGraph/Includes/SelectionPickingPass.hlsl"

// --------------------------------------------------
// Visual Effect Vertex Invocations
#ifdef HAVE_VFX_MODIFICATION
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/VisualEffectVertex.hlsl"
#endif

ENDHLSL
}
}
CustomEditor "UnityEditor.ShaderGraph.GenericShaderGraphMaterialGUI"
CustomEditorForRenderPipeline "UnityEditor.Rendering.Universal.VFXShaderGraphUnlitGUI" "UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset"
FallBack "Hidden/Shader Graph/FallbackError"
}