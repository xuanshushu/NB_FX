using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace NBFX.Baseline.Tests
{
    /// <summary>
    /// G4 ordinary-Mesh render-state B/C only. In-memory shaders create a
    /// nonblack RGBA backdrop, a stencil writer, and a stencil read probe;
    /// no Assets, RendererData, ProjectSettings or VFX state is changed.
    /// </summary>
    public sealed class G4GraphRenderStateTests
    {
        const string GraphPath = "Packages/com.xuanxuan.nb.fx/NBShaders2/ShaderGraph/NBShaderGraph.shadergraph";
        const string LegacyPath = "Packages/com.xuanxuan.nb.fx/NBShaders2/Shader/NBShader.shader";
        const int Size = 128, Layer = 2;
        static readonly int[] ColorMasks = { 0, 1, 2, 4, 8, 3, 5, 10, 15 };
        static readonly string[] StencilCases =
            { "always", "never", "equal", "not-equal", "read-high", "write-low" };

        Shader _backgroundShader, _writerShader, _probeShader;

        [OneTimeSetUp]
        public void CreateTestOnlyShaders()
        {
            AssetDatabase.ImportAsset(GraphPath, ImportAssetOptions.ForceUpdate |
                ImportAssetOptions.ForceSynchronousImport);
            _backgroundShader = MakeAuxiliaryShader("Backdrop", "", "RGBA",
                "half4(0.125, 0.25, 0.5, 0.25)");
            _writerShader = MakeAuxiliaryShader("StencilWriter",
                "Stencil { Ref [_WriterRef] Comp Always Pass Replace ReadMask 255 WriteMask [_WriterMask] }",
                "0", "half4(0, 0, 0, 0)");
            _probeShader = MakeAuxiliaryShader("StencilProbe",
                "Stencil { Ref 5 ReadMask 15 Comp Equal Pass Keep }",
                "RGBA", "half4(0.8, 0.1, 0.9, 0.6)");
            Assert.That(_backgroundShader && _writerShader && _probeShader, Is.True,
                "In-memory stencil fixture shaders did not compile.");
        }

        [OneTimeTearDown]
        public void DestroyTestOnlyShaders()
        {
            foreach (var shader in new[] { _backgroundShader, _writerShader, _probeShader })
                if (shader) UnityEngine.Object.DestroyImmediate(shader);
        }

        static Shader MakeAuxiliaryShader(string name, string stencil, string colorMask,
            string output)
        {
            string source = "Shader \"Hidden/NBFX/G4" + name + "\" { " +
                "Properties { _WriterRef(\"Writer Ref\", Float) = 165 " +
                "_WriterMask(\"Writer Mask\", Float) = 255 } " +
                "SubShader { Tags { \"RenderPipeline\"=\"UniversalPipeline\" " +
                "\"Queue\"=\"Geometry\" \"RenderType\"=\"Opaque\" } " +
                "Pass { Tags { \"LightMode\"=\"UniversalForward\" } " +
                "Cull Off ZWrite Off ZTest Always Blend One Zero ColorMask " + colorMask + " " +
                stencil + " HLSLPROGRAM\n#pragma vertex Vert\n#pragma fragment Frag\n" +
                "#include \"Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl\"\n" +
                "struct Attributes { float4 positionOS : POSITION; }; " +
                "struct Varyings { float4 positionCS : SV_POSITION; }; " +
                "Varyings Vert(Attributes input) { Varyings o; " +
                "o.positionCS = TransformObjectToHClip(input.positionOS.xyz); return o; } " +
                "half4 Frag(Varyings input) : SV_Target { return " + output + "; }\n" +
                "ENDHLSL\n} } }";
            var shader = ShaderUtil.CreateShaderAsset(source, false);
            if (shader) shader.hideFlags = HideFlags.HideAndDontSave;
            return shader;
        }

        static IEnumerable<TestCaseData> MaskCases()
        {
            foreach (int mask in ColorMasks)
                foreach (bool ortho in new[] { true, false })
                    yield return new TestCaseData(mask, ortho).SetName(
                        "G4GraphColorMaskBC_" + mask + (ortho ? "_ortho" : "_perspective"));
        }

        static IEnumerable<TestCaseData> StencilData()
        {
            foreach (string stencil in StencilCases)
                foreach (bool ortho in new[] { true, false })
                    yield return new TestCaseData(stencil, ortho).SetName(
                        "G4GraphStencilBC_" + stencil + (ortho ? "_ortho" : "_perspective"));
        }

        [Serializable]
        sealed class Metrics
        {
            public string caseId, unityVersion, graphicsApi, targetFormat, note;
            public bool orthographic, finite, stencilAttachment;
            public int colorMask, differentRGBA, leftVisible, rightVisible;
            public float maxRGBA, graphRepeatMax, legacyRepeatMax, controlMax;
        }

        [TestCaseSource(nameof(MaskCases))]
        public void ColorMaskMatchesOriginalShaderLab(int mask, bool ortho)
        {
            using (var fixture = new Fixture(_backgroundShader, _writerShader, _probeShader,
                ortho, false))
            {
                fixture.ConfigureFront(mask, CompareFunction.Always, 0, 255, 255,
                    StencilOp.Keep);
                fixture.WriterEnabled = false;
                fixture.ProbeEnabled = false;
                RunBC(fixture, "color-mask-" + mask, ortho, mask, false,
                    (empty, b, c, metrics) =>
                    {
                        Color background = empty[64 * Size + 72];
                        Color foreground = c[64 * Size + 72];
                        for (int channel = 0; channel < 4; channel++)
                        {
                            float delta = Mathf.Abs(foreground[channel] - background[channel]);
                            // ShaderLab numeric ColorMask order is R=8/G=4/B=2/A=1.
                            if ((mask & (8 >> channel)) != 0)
                                Assert.That(delta, Is.GreaterThan(.04f),
                                    "Enabled channel did not write: " + channel);
                            else
                                Assert.That(delta, Is.Zero,
                                    "Disabled channel wrote: " + channel);
                        }
                    });
            }
        }

        [TestCaseSource(nameof(StencilData))]
        public void StencilReadAndWriteMasksMatchOriginalShaderLab(string mode, bool ortho)
        {
            if (SupportedStencilFormat() == GraphicsFormat.None)
                Assert.Ignore("No supported 8-bit stencil render attachment; test not run.");
            using (var fixture = new Fixture(_backgroundShader, _writerShader, _probeShader,
                ortho, true))
            {
                int reference = 165, readMask = 255, writeMask = 255;
                CompareFunction compare = CompareFunction.Always;
                StencilOp operation = StencilOp.Keep;
                fixture.WriterEnabled = mode != "always" && mode != "never" && mode != "write-low";
                fixture.ProbeEnabled = mode == "write-low";
                fixture.WriterRef = 165;
                fixture.WriterMask = 255;
                switch (mode)
                {
                    case "always": compare = CompareFunction.Always; break;
                    case "never": compare = CompareFunction.Never; break;
                    case "equal": compare = CompareFunction.Equal; break;
                    case "not-equal": compare = CompareFunction.NotEqual; break;
                    case "read-high": compare = CompareFunction.Equal;
                        reference = 160; readMask = 240; break;
                    case "write-low": compare = CompareFunction.Always;
                        operation = StencilOp.Replace; writeMask = 15; break;
                    default: throw new ArgumentException(mode);
                }
                fixture.ConfigureFront(15, compare, reference, readMask, writeMask,
                    operation);
                RunBC(fixture, "stencil-" + mode, ortho, 15, true,
                    (empty, b, c, metrics) =>
                    {
                        Color left = c[64 * Size + 44], right = c[64 * Size + 84];
                        Color emptyLeft = empty[64 * Size + 44];
                        Color emptyRight = empty[64 * Size + 84];
                        float ld = Delta(left, emptyLeft), rd = Delta(right, emptyRight);
                        bool leftOn = mode == "always" || mode == "equal" ||
                            mode == "read-high" || mode == "write-low";
                        bool rightOn = mode == "always" || mode == "not-equal" ||
                            mode == "write-low";
                        if (leftOn)
                            Assert.That(ld, Is.GreaterThan(.04f),
                                "Left-half stencil positive control failed.");
                        else
                            Assert.That(ld, Is.Zero,
                                "Left-half stencil negative control failed.");
                        if (rightOn)
                            Assert.That(rd, Is.GreaterThan(.04f),
                                "Right-half stencil positive control failed.");
                        else
                            Assert.That(rd, Is.Zero,
                                "Right-half stencil negative control failed.");
                        if (mode == "write-low")
                        {
                            // The late magenta probe sees only bits written by
                            // the NB foreground, not the color of that foreground.
                            fixture.ConfigureFront(15, CompareFunction.Always,
                                165, 255, 0, StencilOp.Replace);
                            var noWrite = fixture.Capture(fixture.Graph, null);
                            metrics.controlMax = MaxDelta(c, noWrite);
                            Assert.That(metrics.controlMax, Is.GreaterThan(.04f),
                                "WriteMask=0 negative control did not disable the probe.");
                        }
                    });
            }
        }

        static GraphicsFormat SupportedStencilFormat()
        {
            foreach (var format in new[] { GraphicsFormat.D24_UNorm_S8_UInt,
                GraphicsFormat.D32_SFloat_S8_UInt })
                if (SystemInfo.IsFormatSupported(format, GraphicsFormatUsage.Render))
                    return format;
            return GraphicsFormat.None;
        }

        static void RunBC(Fixture f, string name, bool ortho, int mask, bool stencil,
            Action<Color[], Color[], Color[], Metrics> verify)
        {
            string root = Environment.GetEnvironmentVariable("NBFX_MESH_EVIDENCE_DIR");
            if (string.IsNullOrEmpty(root))
                root = Path.Combine(Path.GetDirectoryName(Application.dataPath),
                    "Temp/NBFXG4GraphRenderState");
            string dir = Path.Combine(root, name + (ortho ? "-ortho" : "-perspective"));
            Directory.CreateDirectory(dir);

            Color[] empty = f.Capture(null, Path.Combine(dir, "empty"));
            Color[] b = f.Capture(f.Legacy, Path.Combine(dir, "B"));
            Color[] br = f.Capture(f.Legacy, null);
            Color[] c = f.Capture(f.Graph, Path.Combine(dir, "C"));
            Color[] cr = f.Capture(f.Graph, null);
            var metrics = new Metrics
            {
                caseId = name + (ortho ? "-ortho" : "-perspective"),
                unityVersion = Application.unityVersion,
                graphicsApi = SystemInfo.graphicsDeviceType.ToString(),
                targetFormat = f.Target.descriptor.graphicsFormat + "/" +
                    f.Target.descriptor.depthStencilFormat,
                note = "Ordinary Mesh B/C, nonblack RGBA board, steady state; " +
                    "not VFX, first frame, depth/ShadowCaster, or full G4.",
                orthographic = ortho, colorMask = mask, stencilAttachment = stencil,
                finite = Finite(b) && Finite(c),
                maxRGBA = MaxDelta(b, c),
                graphRepeatMax = MaxDelta(c, cr),
                legacyRepeatMax = MaxDelta(b, br),
                leftVisible = Visible(empty, c, 32, 63),
                rightVisible = Visible(empty, c, 64, 95)
            };
            int diff = 0;
            for (int y = 32; y < 96; y++) for (int x = 32; x < 96; x++)
                if (Delta(b[y * Size + x], c[y * Size + x]) != 0f) diff++;
            metrics.differentRGBA = diff;
            try { verify(empty, b, c, metrics); }
            finally
            {
                File.WriteAllText(Path.Combine(dir, "metrics.json"),
                    JsonUtility.ToJson(metrics, true));
                Debug.Log("NBFX_G4_GRAPH_RENDER_STATE " + JsonUtility.ToJson(metrics));
            }
            Assert.That(metrics.finite, Is.True);
            Assert.That(metrics.graphRepeatMax, Is.Zero);
            Assert.That(metrics.legacyRepeatMax, Is.Zero);
            Assert.That(metrics.differentRGBA, Is.Zero,
                "Strict B/C RGBA differs; raw arrays are retained.");
        }

        static int Visible(Color[] empty, Color[] image, int minX, int maxX)
        {
            int count = 0;
            for (int y = 32; y < 96; y++) for (int x = minX; x <= maxX; x++)
                if (Delta(empty[y * Size + x], image[y * Size + x]) > .04f) count++;
            return count;
        }

        static bool Finite(Color[] colors)
        {
            foreach (Color c in colors)
                for (int i = 0; i < 4; i++)
                    if (float.IsNaN(c[i]) || float.IsInfinity(c[i])) return false;
            return true;
        }

        static float Delta(Color a, Color b)
        {
            float max = 0;
            for (int i = 0; i < 4; i++) max = Mathf.Max(max, Mathf.Abs(a[i] - b[i]));
            return max;
        }

        static float MaxDelta(Color[] a, Color[] b)
        {
            float max = 0;
            for (int y = 32; y < 96; y++) for (int x = 32; x < 96; x++)
                max = Mathf.Max(max, Delta(a[y * Size + x], b[y * Size + x]));
            return max;
        }

        sealed class Fixture : IDisposable
        {
            public readonly Material Graph, Legacy;
            public readonly RenderTexture Target;
            readonly Material _background, _writer, _probe;
            readonly Scene _scene;
            readonly GameObject _front, _board, _writerObject, _probeObject, _cameraObject;
            readonly Camera _camera;
            readonly Texture2D _readback;
            readonly RenderTexture _previousActive;
            readonly MeshRenderer _frontRenderer;

            public Fixture(Shader backgroundShader, Shader writerShader, Shader probeShader,
                bool ortho, bool stencil)
            {
                Assert.That(GraphicsSettings.currentRenderPipeline,
                    Is.InstanceOf<UniversalRenderPipelineAsset>());
                Assert.That(SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBHalf), Is.True);
                Shader graphShader = AssetDatabase.LoadAssetAtPath<Shader>(GraphPath);
                Shader legacyShader = AssetDatabase.LoadAssetAtPath<Shader>(LegacyPath);
                Assert.That(graphShader && legacyShader && graphShader.isSupported && legacyShader.isSupported,
                    Is.True);
                Graph = new Material(graphShader);
                Legacy = new Material(legacyShader);
                _background = new Material(backgroundShader);
                _writer = new Material(writerShader);
                _probe = new Material(probeShader);
                ConfigureMaterial(Graph, true);
                ConfigureMaterial(Legacy, false);
                foreach (var property in new[] { "_ColorMask", "_Stencil", "_StencilComp",
                    "_StencilOp", "_StencilFail", "_StencilZFail", "_StencilReadMask",
                    "_StencilWriteMask" })
                    Assert.That(Graph.HasProperty(property) && Legacy.HasProperty(property),
                        Is.True, "Missing render-state property: " + property);

                _scene = EditorSceneManager.NewPreviewScene();
                _front = GameObject.CreatePrimitive(PrimitiveType.Quad);
                _board = GameObject.CreatePrimitive(PrimitiveType.Quad);
                _writerObject = GameObject.CreatePrimitive(PrimitiveType.Quad);
                _probeObject = GameObject.CreatePrimitive(PrimitiveType.Quad);
                _cameraObject = new GameObject("NBFX G4 Graph render-state B/C camera");
                foreach (var go in new[] { _front, _board, _writerObject, _probeObject, _cameraObject })
                {
                    SceneManager.MoveGameObjectToScene(go, _scene);
                    go.layer = Layer;
                }
                _front.transform.position = new Vector3(0, 0, .5f);
                _front.transform.localScale = new Vector3(2, 2, 1);
                _board.transform.position = new Vector3(0, 0, 0);
                _board.transform.localScale = new Vector3(6, 6, 1);
                // Camera yaw180 makes world +X appear on the image left.
                _writerObject.transform.position = new Vector3(.5f, 0, .7f);
                _writerObject.transform.localScale = new Vector3(1, 2, 1);
                _probeObject.transform.position = new Vector3(0, 0, .8f);
                _probeObject.transform.localScale = new Vector3(2, 2, 1);
                _frontRenderer = SetMaterial(_front, Graph);
                SetMaterial(_board, _background);
                SetMaterial(_writerObject, _writer);
                SetMaterial(_probeObject, _probe);
                _background.renderQueue = 1000;
                _writer.renderQueue = 2000;
                Graph.renderQueue = Legacy.renderQueue = 3000;
                _probe.renderQueue = 3100;
                _writerObject.SetActive(false);
                _probeObject.SetActive(false);

                var descriptor = new RenderTextureDescriptor(Size, Size,
                    RenderTextureFormat.ARGBHalf, 24);
                descriptor.msaaSamples = 1;
                descriptor.sRGB = false;
                if (stencil) descriptor.depthStencilFormat = SupportedStencilFormat();
                Target = new RenderTexture(descriptor) { filterMode = FilterMode.Point };
                Target.Create();
                Assert.That(Target.IsCreated(), Is.True);
                if (stencil)
                    Assert.That(Target.descriptor.depthStencilFormat,
                        Is.EqualTo(SupportedStencilFormat()));
                _readback = new Texture2D(Size, Size, TextureFormat.RGBAHalf, false, true);
                _camera = _cameraObject.AddComponent<Camera>();
                _camera.scene = _scene;
                _camera.transform.position = new Vector3(0, 0, 5);
                _camera.transform.rotation = Quaternion.Euler(0, 180, 0);
                _camera.orthographic = ortho;
                _camera.orthographicSize = 1.5f;
                _camera.fieldOfView = 45;
                _camera.nearClipPlane = .1f;
                _camera.farClipPlane = 20;
                _camera.cullingMask = 1 << Layer;
                _camera.clearFlags = CameraClearFlags.SolidColor;
                _camera.backgroundColor = Color.black;
                _camera.allowHDR = true;
                _camera.allowMSAA = false;
                _camera.targetTexture = Target;
                _previousActive = RenderTexture.active;
            }

            static MeshRenderer SetMaterial(GameObject go, Material material)
            {
                var renderer = go.GetComponent<MeshRenderer>();
                renderer.sharedMaterial = material;
                renderer.shadowCastingMode = ShadowCastingMode.Off;
                renderer.receiveShadows = false;
                return renderer;
            }

            static void ConfigureMaterial(Material material, bool graph)
            {
                material.SetTexture("_BaseMap", Texture2D.whiteTexture);
                material.SetColor(graph ? "_Color" : "_BaseColor", Color.white);
                material.SetColor("_ColorA", Color.white);
                material.SetFloat("_AlphaAll", 1);
                material.SetFloat("_BaseColorIntensityForTimeline", 1);
                material.SetFloat("_Cull", 0);
                material.SetFloat("_ZTest", 4);
                material.SetFloat("_ZWrite", 0);
                material.SetFloat("_SrcBlend", (float)BlendMode.One);
                material.SetFloat("_DstBlend", (float)BlendMode.Zero);
                if (graph)
                {
                    material.SetFloat("_Surface", 1);
                    material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
                    material.SetFloat("_SrcBlendAlpha", (float)BlendMode.One);
                    material.SetFloat("_DstBlendAlpha", (float)BlendMode.Zero);
                    material.SetFloat("_NB_DistortionMode", 0);
                    material.SetFloat("_NB_ColorChannelLo16", 3);
                    material.SetFloat("_NB_Flags1Lo16", 1 << 9);
                }
                else
                {
                    material.EnableKeyword("_FX_LIGHT_MODE_UNLIT");
                    material.SetFloat("_fogintensity", 0);
                    material.SetInteger("_W9ParticleShaderColorChannelFlag", 3);
                    material.SetInteger("_W9ParticleShaderFlags1", 1 << 9);
                    material.SetShaderPassEnabled("SRPDefaultUnlit", false);
                    material.SetShaderPassEnabled("SRPDEFAULTUNLIT", false);
                }
            }

            public bool WriterEnabled { set => _writerObject.SetActive(value); }
            public bool ProbeEnabled { set => _probeObject.SetActive(value); }
            public int WriterRef { set => _writer.SetFloat("_WriterRef", value); }
            public int WriterMask { set => _writer.SetFloat("_WriterMask", value); }

            public void ConfigureFront(int colorMask, CompareFunction comp, int reference,
                int readMask, int writeMask, StencilOp operation)
            {
                foreach (Material m in new[] { Graph, Legacy })
                {
                    m.SetFloat("_ColorMask", colorMask);
                    m.SetFloat("_Stencil", reference);
                    m.SetFloat("_StencilComp", (float)comp);
                    m.SetFloat("_StencilOp", (float)operation);
                    m.SetFloat("_StencilFail", (float)StencilOp.Keep);
                    m.SetFloat("_StencilZFail", (float)StencilOp.Keep);
                    m.SetFloat("_StencilReadMask", readMask);
                    m.SetFloat("_StencilWriteMask", writeMask);
                }
            }

            public Color[] Capture(Material front, string path)
            {
                _frontRenderer.enabled = front != null;
                if (front != null) _frontRenderer.sharedMaterial = front;
                for (int i = 0; i < 4; i++) _camera.Render();
                RenderTexture.active = Target;
                _readback.ReadPixels(new Rect(0, 0, Size, Size), 0, 0);
                _readback.Apply(false);
                var colors = _readback.GetPixels();
                if (path != null)
                {
                    using (var file = File.Create(path + ".rgba-f32.gz"))
                    using (var gzip = new GZipStream(file, CompressionMode.Compress))
                    using (var writer = new BinaryWriter(gzip))
                        foreach (Color color in colors)
                        { writer.Write(color.r); writer.Write(color.g); writer.Write(color.b); writer.Write(color.a); }
                    var image = new Texture2D(Size, Size, TextureFormat.RGBA32, false, true);
                    try { image.SetPixels(colors); image.Apply(false);
                        File.WriteAllBytes(path + ".png", image.EncodeToPNG()); }
                    finally { UnityEngine.Object.DestroyImmediate(image); }
                }
                return colors;
            }

            public void Dispose()
            {
                _camera.targetTexture = null;
                RenderTexture.active = _previousActive;
                Target.Release();
                foreach (var obj in new UnityEngine.Object[]
                    { Graph, Legacy, _background, _writer, _probe, Target, _readback })
                    if (obj) UnityEngine.Object.DestroyImmediate(obj);
                EditorSceneManager.ClosePreviewScene(_scene);
            }
        }
    }
}
