#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UVP0 / schema / primitive-scaffold REVIEW PREVIEW ONLY.

Reads latest live package per invocation, writes only /tmp. It does NOT wire
position ports/custom interpolators or claim positional UV implemented.
All old Graph serialized objects/ports/edges are exact-preserved except root
properties list with 8 append-only real legacy fields. Fixed source manifest
prevents silently applying stale candidates after other slice integration.
"""
from pathlib import Path
import copy, difflib, hashlib, json, uuid, re
P=Path('/Users/bytedance/UnityProject/NBUnityProject/Packages/NB_FX')
O=Path('/tmp/nbfx-position-uv-candidate/preview')
assert str(O).startswith('/tmp/')
NS=uuid.UUID('9f8f4842-eb4e-4b7b-9d38-cdf8f87773eb')
FILES={'graph':'NBShaders2/ShaderGraph/NBShaderGraph.shadergraph',
       'shared':'NBShaders2/Shader/HLSL/NBShaderUVV1.hlsl',
       'uv':'NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl',
       'vertex':'NBShaders2/ShaderGraph/NBGraphVertexOffset.hlsl',
       'host':'NBShaders2/ShaderGraph/Editor/NBGraphUnlitSubTarget.cs'}
def h(x):return hashlib.sha256(x).hexdigest()
def uid(s):return uuid.uuid5(NS,'UVP0:'+s).hex

def decode(s):
 d=json.JSONDecoder();i=0;arr=[]
 while i<len(s):
  while i<len(s) and s[i].isspace():i+=1
  if i==len(s):break
  x,i=d.raw_decode(s,i);arr.append(x)
 assert arr and arr[0]['m_Type']=='UnityEditor.ShaderGraph.GraphData'
 return arr

def literal_split(s):
 sig='BaseUVs NBFX_BuildBaseUVsV1(NBFX_BaseUVInputV1 input, NBFX_BaseUVParamsV1 parameters)'
 assert s.count(sig)==1
 a=s.index(sig);start=s.index('{',a)+1
 tail='    // Preserve original ordering: shared UV is available when main UV mode is'
 b=s.index(tail,start)
 end=s.index('\n}\n',b)
 sources=s[start:b]
 resolve=s[b:end]
 assert sources.count('BaseUVs baseUVs = (BaseUVs)0;')==1
 assert resolve.count('    return baseUVs;')==1
 # Move only literal blocks across a by-value BaseUVs seam: no math/cast/order rewrite.
 new='''BaseUVs NBFX_BuildBaseUVSourcesV1(NBFX_BaseUVInputV1 input, NBFX_BaseUVParamsV1 parameters)
{'''+sources+'''    return baseUVs;
}

BaseUVs NBFX_ResolveSharedMainUVsV1(NBFX_BaseUVInputV1 input,
    NBFX_BaseUVParamsV1 parameters, BaseUVs baseUVs)
{
'''+resolve+'''
}

'''+sig+'''
{
    BaseUVs baseUVs = NBFX_BuildBaseUVSourcesV1(input, parameters);
    return NBFX_ResolveSharedMainUVsV1(input, parameters, baseUVs);
}'''
 # Prove moved source and tail math remain byte-identical.
 assert sources in new and resolve in new
 return s[:a]+new+s[end+2:]

SCAFFOLD=r'''
// UVP review scaffold only: new node MUST be force-Single and run before
// VertexOffset. No Graph node is wired by this preview. CustomLocal/VAT are
// independent hosts; this binds current ordinary Mesh's raw object position.
// The shared Sources function owns cylinder/order/plane arithmetic.
void NBGraphUVVertexSources_float(float3 PositionOS, float4 UV0,
    float Flags1Lo16, float Flags1Hi16,
    float WorldSelector, float ObjectSelector,
    float4 CylinderMatrix0, float4 CylinderMatrix1,
    float4 CylinderMatrix2, float4 CylinderMatrix3,
    out float4 PreCylinderScreen, out float4 PreWorldObject)
{
    NBFX_BaseUVInputV1 input = (NBFX_BaseUVInputV1)0;
    input.meshTexcoord0 = UV0;
    input.positionOS = PositionOS;
    input.positionWS = TransformObjectToWorld(PositionOS);
    float4 preClip = TransformObjectToHClip(PositionOS);
    input.screenUV = preClip.xy / preClip.w;
    input.screenUV = input.screenUV * 0.5 + 0.5;
    NBFX_BaseUVParamsV1 parameters = (NBFX_BaseUVParamsV1)0;
    parameters.flags1 = NBGraphDecodeUInt32(Flags1Lo16, Flags1Hi16) &
        FLAG_BIT_PARTICLE_1_CYLINDER_CORDINATE;
    parameters.worldSpaceUVModeSelector = (half)WorldSelector;
    parameters.objectSpaceUVModeSelector = (half)ObjectSelector;
    parameters.cylinderUVMatrix = float4x4(CylinderMatrix0, CylinderMatrix1,
        CylinderMatrix2, CylinderMatrix3);
    BaseUVs sources = NBFX_BuildBaseUVSourcesV1(input, parameters);
    PreCylinderScreen = float4(sources.cylinderUV, sources.screenUV);
    PreWorldObject = float4(sources.worldPosUV, sources.objectPosUV);
}
'''

def schema(objects):
 graph=copy.deepcopy(objects);idx={x['m_ObjectId']:x for x in graph}
 props={x.get('m_OverrideReferenceName') or x.get('m_DefaultReferenceName'):x for x in graph if x.get('m_Type','').endswith('ShaderProperty')}
 spec=[('_WorldSpaceUVModeSelector',1.0,False),('_ObjectSpaceUVModeSelector',1.0,False),
       ('_CylinderUVRotate',[0.,0.,90.,0.],False),('_CylinderUVPosOffset',[0.,0.,0.,0.],False)]
 spec += [('_CylinderMatrix'+str(i),[0.,0.,0.,0.],True) for i in range(4)]
 additions=[]
 scalar=next(x for x in graph if x.get('m_Type','').endswith('Vector1ShaderProperty') and x.get('m_OverrideReferenceName')=='_ParallaxMapping_Toggle')
 vector=next(x for x in graph if x.get('m_Type','').endswith('Vector4ShaderProperty') and x.get('m_OverrideReferenceName')=='_BaseMap_ST')
 for name,val,hidden in spec:
  assert name not in props,'Already exists: inspect actual integration before replay '+name
  x=copy.deepcopy(scalar if isinstance(val,float) else vector)
  x['m_ObjectId']=uid('prop:'+name)
  assert x['m_ObjectId'] not in idx
  x['m_Guid']={'m_GuidSerialized':str(uuid.UUID(uid('guid:'+name)))}
  x['m_Name']=name[1:];x['m_RefNameGeneratedByDisplayName']=name[1:]
  x['m_DefaultReferenceName']=name;x['m_OverrideReferenceName']=name
  x['m_Hidden']=hidden;x['m_Precision']=1;x['m_Value']=val if isinstance(val,float) else dict(zip('xyzw',val))
  if isinstance(val,float):x['m_FloatType']=0
  graph.append(x);graph[0]['m_Properties'].append({'m_Id':x['m_ObjectId']});additions.append(x)
 # Exact serialized preservation: only root properties list + 8 new objects.
 assert len(graph)==len(objects)+8
 for old,new in zip(objects,graph):
  if old is objects[0]:
   a=copy.deepcopy(old);b=copy.deepcopy(new);a.pop('m_Properties');b.pop('m_Properties');assert a==b
   assert new['m_Properties'][:-8]==old['m_Properties']
  else:assert old==new
 return graph,additions

def inventory(objects,src):
 idx={o['m_ObjectId']:o for o in objects};out={}
 for obj in objects:
  if obj.get('m_FunctionName') in ('NBGraphBaseUV','NBGraphVertexOffset'):
   slots=[idx[r['m_Id']] for r in obj['m_Slots']]
   out[obj['m_FunctionName']]={'nodeId':obj['m_ObjectId'],'slots':[{'id':s['m_Id'],'name':s['m_DisplayName'],'type':s['m_Type'],'direction':s['m_SlotType'],'objectId':s['m_ObjectId']} for s in slots]}
 customs=[]
 for ref in objects[0]['m_VertexContext']['m_Blocks']:
  obj=idx[ref['m_Id']];desc=obj.get('m_SerializedDescriptor','')
  if '#' in desc:
   name,width=desc.split('#');customs.append({'name':name,'width':int(width),'objectId':obj['m_ObjectId']})
 out['customInterpolatorsActual']=customs
 out['actualCustomComponentCount']=sum(x['width'] for x in customs)
 out['proposedAddedComponents']=11;out['projectedCustomComponentCount']=out['actualCustomComponentCount']+11
 out['fixedSourceHash']={k:h(v) for k,v in src.items()}
 out['pendingPositionInputSlots']=[['PostPositionOS','float3'],['PositionWS','float3'],['PreCylinderScreen','float4'],['PreWorldObject','float4'],['WorldSelector','float'],['ObjectSelector','float']]+[['CylinderMatrix'+str(i),'float4'] for i in range(4)]+[['ParallaxToggle','float']]
 out['notImplementedByThisPreview']=['BaseUV_CF_append_binding','custom_interpolator_nodes_and_edges','post_OS_binding','static_pass_fragment_stage_selection','VertexOffset_modes3to7_inputs','13_feature_vertex_transform_precision','Graph_GUI_cylinder_matrix_install','remaining6_consumer_fixtures']
 return out

src={k:(P/v).read_bytes() for k,v in FILES.items()}
objects=decode(src['graph'].decode())
graph,additions=schema(objects)
newshared=literal_split(src['shared'].decode())
newuv=src['uv'].decode();assert newuv.rstrip().endswith('#endif')
assert 'NBGraphUVVertexSources_float' not in newuv
last=newuv.rindex('#endif');newuv=newuv[:last]+SCAFFOLD+'\n'+newuv[last:]
outputs={FILES['graph']:'\n\n'.join(json.dumps(x,indent=4,ensure_ascii=False) for x in graph)+'\n', FILES['shared']:newshared, FILES['uv']:newuv}
O.mkdir(parents=True,exist_ok=True)
manifest={'scope':'REVIEW ONLY UVP0 literal split + 8 real schema fields + unconnected vertex scaffold; NOT full positional product',
 'source':{FILES[k]:{'sha256':h(v),'bytes':len(v)} for k,v in src.items()},'candidate':{},
 'graphOldObjectCount':len(objects),'graphNewObjectCount':len(graph),'graph8AppendOnlyFields':[x['m_OverrideReferenceName'] for x in additions],
 'oldGraphObjectsPreservedExceptRootProperties':True,'oldGraphEdgesPortsKeywordsTargetsSupportVFXPreserved':True,'sharedSourceTailLiteralBytePreserved':True,
 'ranUnity':False,'packageFilesWritten':False,'featureComplete':False}
for rel,s in outputs.items():
 path=O/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(s)
 old=(P/rel).read_text();diff=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='original/'+rel,tofile='candidate/'+rel))
 # Graph global indentation normalization obscures change; semantic exactness verified separately.
 if rel==FILES['graph']:
  diff='Graph semantic-only changes: m_Properties append 8 refs; append 8 corresponding real properties. Every old object/edge/port/target is verified identical.\n'+json.dumps(additions,indent=2)+'\n'
 (O/(Path(rel).name+'.diff')).write_text(diff)
 manifest['candidate'][rel]={'sha256':h(path.read_bytes()),'bytes':path.stat().st_size}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(O/'current-interface-inventory.json').write_text(json.dumps(inventory(objects,src),indent=2)+'\n')
# Check files remain unchanged while read/preview (avoid integrating across another agent's write).
for key,data in src.items():assert (P/FILES[key]).read_bytes()==data,'Live source changed during preview: rerun '+key
print(json.dumps({'manifest':str(O/'manifest.json'),'source_graph':manifest['source'][FILES['graph']]['sha256'],'old_objects':len(objects),'new_objects':len(graph),'custom_components':inventory(objects,src)['actualCustomComponentCount'],'complete':False},indent=2))
