UVP1 普通 Mesh 位置 UV 完整接线候选（未应用、未运行 Unity）

本目录是可供 Root 逐文件 review/apply 的完整候选，不是上一版 schema/scaffold。
入口：/tmp/nbfx-position-uv-candidate/dynamic-preview.py
每次重新读取最新产品，输出只/tmp；apply 前必须验证 manifest inputSHA256。
仅四产品路径：NBGraphBaseUV.hlsl、NBGraphVertexOffset.hlsl、NBShaderGraph.shadergraph、包内NBGraphUnlitSubTarget.cs。
旧ShaderLab、NBShaderUVV1共享算术、NBShaderInput、ForwardPass、BaseColor CF/官方包/Target/NBPostprocess均不改。
上次 UVP0 literal helper 拆分预览不需要应用；不要把 /preview 旧三个文件和本目录混合。

做了什么
1) 新 vertex CF 的原位置源复用 FG Fog 和 VertexOffset 正在共用的 raw Object Position（9700a0e...，input0），同一UV0/1/2和材质节点。
   纯调用已有 NBFX_BuildBaseUVsV1，未复制圆柱/UV模式/Shared/Main 算法。
2) 输出3个float4：preCylinder+preScreen，preWorld+preObject，preShared+完整preMain。
   Main包括旧rotation/ST/offset，在VertexOffset前顶点算完再插值；Shared4的zero-before-Main顺序自然来自唯一helper。
3) 另一个float3自定义插值连接现VertexOffset.OutPositionOS，片元真实postOS；WorldPosition复用现BaseColor的world node。
   片元Screen复用已有Pixel节点+经过DD验证的NBGraphDecalRasterUV撤销SG Yflip。
4) 非forced-fragment：Build共享结果后覆盖四空间来源及完整Shared/Main为vertex准备值；13个feature源出口继续唯一GetUVByUVMode选择。
   forced-fragment：Twirl/Polar；主Forward的Decal/POM；两个确切NB扭曲Pass恒true。
   Depth/Shadow/普通2D不因材质POM/Decal uniform误切；Preview保留旧Graph片元求值，不读无vertex的零custominterpolator。
5) Deferred Pass的identity使用包内WithNBPassDefine早期pre-CF static define；CameraOpaque和main原define保持。
   不拿Material RuntimeDistortMode猜当前Pass，不新增keyword/variant axis，不改官方Target。
6) VertexOffset追加真实MainST/rotation/offset、selectors/matrix：world/screen/cylinder均用原preVO位置和clip。
   两个采样UV仍half2、LOD0、自己ST/scroll/方向/强度顺序原样；mode4读已变换Main后再自己的ST。
   0..8真实来源可用；原协议9..15保持GetUVByUVMode默认UV0语义，不擅自赋新意义。
7) 8个原名真实属性(default完全匹配旧ShaderLab)；不建旧int/packed影子，不改已有property defaults/slot IDs/SupportVFX/keywords。

阶段/类型审计
- Graph997→1090，只有Root、category、BaseUV node、VertexOffset node四个旧objects改变（追加list/precision-Single）；全部旧slots/edges逐字语义保留。
- 原23 customcomponents→38（3*float4+postOS3新增15）。当前noncustom9+URP padding16预算=63components/15.75float4，小于默认warning16；只是官方SG校验预算，不是Metal实际varying/register或性能证明。
- 新位置vertex、CI、BaseUV、VO节点force-Single；原selector仍half赋值边界，rows为float4，flags lo/hi从不half转换。
- 新BaseUV输入12，IDs37..48；VO输入10，IDs37..46。全部旧端口原名/顺序/ID保留，Graph CF InputSlots+OutputSlots顺序与HLSL实际签名静态逐项吻合。
- PostPositionOS来自VO输出，不拿TransformWorldToObject替代普通Mesh原object varying；仅Preview fallback用world->object，因为官方preview不供应真实CI。
- 同Raw位置源目前是Object PositionNode。未来VAT/CustomLocal插入时必须改同一preVO接缝：其输出PositionOS同时供FG Fog、UVVertex、VO；preVO NormalOS也接VO/几何基础。UVVertex不需要normal作UV参数，不能改接最终位移后OS。当前builder对已知raw节点有审计断言，future host接入后应明确复审此断言而非偷偷绕过。

不是已经完成的功能
- 每个feature自己的ST/rotation/scroll目前仍在原BaseColor消费CF阶段；本片保证Source stage +完整Main/Shared stage，但不假称literal全部ParticleProcessUV最终变换已移植。
  数学仿射交换不保证float严格0。376原始strict测试发现微差要记录；不能换阈值/伪造CPU公式。是否需要下片抽其共享纯transform并传更多varyings由真实结果决定。
- 完整CustomData UV偏移字、CustomLocalTransform、VAT、Matrix GUI自动安装、Tier/intent、2D screen-mode完整组合、真实VFX/Player/完整MeshG3/G4/NBPostprocessController链仍pending。
- Vertex3..7接口本片实现候选，但新376fixture不测VertexOffset几何（继承旧14回归不能替代新位置几何用例）；Noise/Mask/Bump/PNoise位置来源也需要各现fixture追加，不能只凭代码叫正式通过。
- 没有Unity Shader/HLSL compilation/readiness或图像实测结论。Root应用后独占隔离Unity导入/console/串行验证。

新测试候选（尚只/tmp，不copy中央）
/tmp/nbfx-position-uv-candidate/G4GraphPositionUVTests.cs/.meta
- 376=9consumer(Main+8已有真实FeatureUV setter)*5modes3..7*direct/shared*vertex/强制fragment*两相机360 + Main6/7两其它axes16。
- actualFrozen/current/Graph；非平面coarse Mesh+旋转/非均匀缩放；先真实URP Camera暖Graph再验证8真实property/type和实际Forward。
- strongcounterfactual；RGBAraw float32 gzip + PNG；finite全帧，ROI40..87严格0，重复严格0，visible和response强断言。
- Main自读mode4须与route0严格等价，再改变MainST作强control；Shared4仍原zero-source，不错误期待递归MainUV。
- 使用真实NBShaderFlags反射SetUVMode/SetFlagBits，不另实现packed writer，也不修改现URP asmdef。原fixture程序集本来没NB runtime引用；离线编译以真实URP references +现FeatureUV源码成功。
- consumer-batches.json：9独立process，Main56、其它各40，regex有官方本地UITestRunnerFilter Regex实现依据；完整376覆盖，不删case。
- 分批不是假设固定某draw数量安全。已知CA短POM也宿主空图，根因未证实。捕获全零/NaN/repeat失败不能当B/C0通过。

离线检查
- static-structural-audit.json：三CF签名/序列化slot types匹配；all edges valid；unique input fanin；含CI隐式vertex->fragment关系的DAG无cycle；旧source不变。
- static-compile-result.json：新fixture，真实现URP assembly refs，Roslyn exit0。
- static-subtarget-result.json：真实URP Editor整个程序集源+只替换该候选，Roslyn exit0。
  初次输出文件改名导致InternalsVisibleTo不认程序集identity，产生访问错误；保留static-subtarget-renamed-identity.log。纠正只/tmp输出为Unity.RenderPipelines.Universal.Editor.dll后exit0，无官方/产品改动。这不是Unity导入测试。
- /tmp bin/dll/pdb都不是产品，不可复制进package；只供离线检查。
