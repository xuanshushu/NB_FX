#!/usr/bin/env python3
"""Read-only structural audit. Does not compile HLSL or execute Unity."""
from pathlib import Path
import json,re,hashlib
D=Path('/tmp/nbfx-position-uv-candidate');O=D/'full-preview'
P=Path('/Users/bytedance/UnityProject/NBUnityProject/Packages/NB_FX')
manifest=json.loads((O/'manifest.json').read_text());graph=O/'NBShaders2/ShaderGraph/NBShaderGraph.shadergraph'
dec=json.JSONDecoder();i=0;arr=[];s=graph.read_text()
while i<len(s):
 while i<len(s) and s[i].isspace():i+=1
 if i==len(s):break
 x,i=dec.raw_decode(s,i);arr.append(x)
by={x['m_ObjectId']:x for x in arr};root=arr[0]
assert len(by)==len(arr),'Duplicate object IDs'

def signature(text,name):
 a=text.index('void '+name+'(')+len('void '+name+'(');b=text.index(')',a)
 parts=[]
 for x in text[a:b].split(','):
  x=x.strip();m=re.fullmatch(r'(out )?(float[234]?|half[234]?|UnityTexture2D)\s+(\w+)',x);assert m,(name,x)
  parts.append({'direction':1 if m[1] else 0,'type':m[2],'name':m[3]})
 return parts
checks={}
for name,rel in [('NBGraphBaseUV','NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl'),('NBGraphUVVertex','NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl'),('NBGraphVertexOffset','NBShaders2/ShaderGraph/NBGraphVertexOffset.hlsl')]:
 node=next(x for x in arr if x.get('m_FunctionName')==name)
 serialized=[]
 for direction in (0,1):
  for ref in node['m_Slots']:
   slot=by[ref['m_Id']]
   if slot['m_SlotType']!=direction:continue
   type_name=slot['m_Type'].split('.')[-1]
   types={'Vector1MaterialSlot':'float','Vector2MaterialSlot':'float2','UVMaterialSlot':'float2','Vector3MaterialSlot':'float3','Vector4MaterialSlot':'float4','Texture2DInputMaterialSlot':'UnityTexture2D'}
   assert type_name in types,type_name
   serialized.append({'direction':direction,'type':types[type_name],'name':slot['m_DisplayName']})
 sig=signature((O/rel).read_text(),name+'_float');assert sig==serialized,(name,sig,serialized)
 assert node['m_Precision']==1,'Float-only vertex CF must be force-Single, not inherit.'
 checks[name]={'inputCount':sum(x['direction']==0 for x in sig),'outputCount':sum(x['direction']==1 for x in sig),'orderedSignatureMatchesActualSerializedSlots':True,'forceSingle':True}
# The wrapper signature has same appended float geometry/matrix/flags (not
# accidentally halfword cast); old half outputs and original arguments remain.
uv=(O/'NBShaders2/ShaderGraph/NBGraphBaseUV.hlsl').read_text();half=signature(uv,'NBGraphBaseUV_half');full=signature(uv,'NBGraphBaseUV_float')
assert [x['name'] for x in half]==[x['name'] for x in full]
for x in half:
 if x['name'] in ('PostPositionOS','PositionWS','PreCylinderScreen','PreWorldObject','PreSharedMain','WorldSelector','ObjectSelector','ParallaxToggle') or x['name'].startswith('CylinderMatrix'):assert x['type'].startswith('float')
# All edge endpoints refer to actual nodes/slot IDs; one input fan-in only.
node_slots={x['m_ObjectId']:{by[r['m_Id']]['m_Id'] for r in x.get('m_Slots',[])} for x in arr if 'm_Slots' in x}
ins=set();edges=[]
for e in root['m_Edges']:
 for key in ('m_OutputSlot','m_InputSlot'):
  q=e[key];assert q['m_Node']['m_Id'] in node_slots and q['m_SlotId'] in node_slots[q['m_Node']['m_Id']],(key,q)
 inp=(e['m_InputSlot']['m_Node']['m_Id'],e['m_InputSlot']['m_SlotId']);assert inp not in ins,inp;ins.add(inp)
 edges.append((e['m_OutputSlot']['m_Node']['m_Id'],e['m_InputSlot']['m_Node']['m_Id']))
# Custom interpolators are implicit vertex->fragment edges; include those to
# detect a preOffset<->postOffset dependency loop that JSON edges alone miss.
for ci in arr:
 if not ci.get('customBlockNodeName'):continue
 block=next(x for x in arr if x.get('m_SerializedDescriptor','').split('#')[0]=='VertexDescription.'+ci['customBlockNodeName'])
 edges.append((block['m_ObjectId'],ci['m_ObjectId']))
adj={n:[] for n in node_slots}
for a,b in edges:adj[a].append(b)
vis={}
def visit(n):
 assert vis.get(n)!=1,'Graph stage cycle: '+n
 if vis.get(n)==2:return
 vis[n]=1
 for m in adj[n]:visit(m)
 vis[n]=2
for n in adj:visit(n)
# Full case inventory from the exact simple C# generator, not a GPU result.
consumers=['main','mask1','mask2','mask3','overlay1','overlay2','color-ramp','dissolve','dissolve-mask']
names={c:[] for c in consumers}
def case(c,s,shared,frag,ortho,axis):return 'G4PositionUVABC_'+c+'_'+('shared' if shared else 'direct')+str(s)+'_axis'+str(axis)+('_fragment' if frag else '_vertex')+('_ortho' if ortho else '_perspective')
for c in consumers:
 for source in range(3,8):
  for shared in (False,True):
   for frag in (False,True):
    for ortho in (True,False):names[c].append(case(c,source,shared,frag,ortho,1))
for source in (6,7):
 for axis in (0,2):
  for frag in (False,True):
   for ortho in (True,False):names['main'].append(case('main',source,False,frag,ortho,axis))
flat=[n for v in names.values() for n in v];assert len(flat)==len(set(flat))==376
batch=[{'consumer':c,'expectedCaseCount':len(names[c]),'testFilterRegex':'^NBFX\\.Baseline\\.Tests\\.G4GraphPositionUVTests\\.G4PositionUVABC_'+re.escape(c)+'_', 'exactCases':names[c]} for c in consumers]
(D/'consumer-batches.json').write_text(json.dumps({'scope':'candidate selection inventory only, unrun','cases':376,'independentProcesses':9,'actualNUnitDiscoveryNotRun':True,'source':'G4GraphPositionUVTests.Cases() simple generator mirrored and exact names checked','batches':batch},indent=2)+'\n')
for rel,h in manifest['readonlyDependencies'].items():assert hashlib.sha256((P/rel).read_bytes()).hexdigest()==h,'Read-only legacy/shared dependency changed: '+rel
for rel,data in manifest['files'].items():assert hashlib.sha256((P/rel).read_bytes()).hexdigest()==data['inputSHA256'],'Live product input changed: '+rel
result={'scope':'static structural checks only (NOT Unity/HLSL compilation or rendering)',
 'CFChecks':checks,'allEdgeEndpointsValid':True,'singleInputFanIn':True,'noCyclesIncludingImplicitCIStages':True,
 'oldEdgesAndObjectsVerifiedByBuilder':True,'legacySharedSourceByteUnchanged':True,'completeCandidateFiles':len(manifest['files']),
 'caseInventory376':True,'consumerCounts':{k:len(v) for k,v in names.items()},'packedWordSchemaChanged':False,
 'noNewKeyword':True,'staticPassDefine':'NB_GRAPH_DEFERRED_DISTORT_PASS added in package AddDistortionPass only'}
(D/'static-structural-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
