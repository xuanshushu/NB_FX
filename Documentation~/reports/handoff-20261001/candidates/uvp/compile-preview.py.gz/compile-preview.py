#!/usr/bin/env python3
"""Offline C# signature check only. Does not launch Unity or write clone/package."""
from pathlib import Path
import subprocess
clone=Path('/tmp/NBFXG2DissolveMaskProbe-20260928')
out=Path('/tmp/nbfx-position-uv-candidate')
bee=clone/'Library/Bee/artifacts/200b0aEDbg.dag'
lines=(bee/'NBFX.G2.URP.Editor.Tests.rsp').read_text().splitlines()
actual=[]
for line in lines:
 if line.startswith(('-out:', '-refout:', '-analyzer:', '-additionalfile:')):continue
 if line.startswith('"'):continue  # original assembly's source files
 actual.append(line)
actual += ['-out:"'+str(out/'NBFX.G4.PositionUV.StaticCheck.dll')+'"',
 '"/Users/bytedance/UnityProject/NBUnityProject/Packages/NB_FX/Tests/URP/Editor/G4GraphFeatureUVTests.cs"',
 '"'+str(out/'G4GraphPositionUVTests.cs')+'"']
path=out/'static-compile.rsp';path.write_text('\n'.join(actual)+'\n')
sdk='/Applications/Unity/Hub/Editor/6000.3.18f1/Unity.app/Contents/Resources/Scripting/'
p=subprocess.run([sdk+'NetCoreRuntime/dotnet', sdk+'DotNetSdkRoslyn/csc.dll','@'+str(path)], cwd=clone, capture_output=True,text=True)
(out/'static-compile.log').write_text(p.stdout+p.stderr)
import json,hashlib
(out/'static-compile-result.json').write_text(json.dumps({'exitCode':p.returncode,'UnityLaunched':False,'fixtureSHA256':hashlib.sha256((out/'G4GraphPositionUVTests.cs').read_bytes()).hexdigest(),'usesActualURPAssemblyReferencesOnly':True,'fixtureDirectNBAssemblyReference':False},indent=2)+'\n')
print(p.stdout+p.stderr);print('Offline C# compiler exit:',p.returncode)
raise SystemExit(p.returncode)
