#!/usr/bin/env python3
"""Compile the actual URP Editor assembly source with just candidate substitution.
No Unity launch, clone/package writes, or official package changes. Output /tmp.
"""
from pathlib import Path
import subprocess,json,hashlib
clone=Path('/tmp/NBFXG2DissolveMaskProbe-20260928')
repo=Path('/Users/bytedance/UnityProject/NBUnityProject/Packages/NB_FX')
out=Path('/tmp/nbfx-position-uv-candidate')
preview=out/'full-preview/NBShaders2/ShaderGraph/Editor/NBGraphUnlitSubTarget.cs'
bee=clone/'Library/Bee/artifacts/200b0aEDbg.dag'
name='Unity.RenderPipelines.Universal.Editor'
(out/'static-subtarget').mkdir(exist_ok=True)
lines=(bee/(name+'.rsp')).read_text().splitlines();actual=[]
for line in lines:
 if line.startswith('-out:'):line='-out:"'+str(out/'static-subtarget/Unity.RenderPipelines.Universal.Editor.dll')+'"'
 elif line.startswith(('-refout:','-analyzer:','/additionalfile:','-additionalfile:')):continue
 elif line.startswith('"Packages/NB_FX/'):
  rel=line[1:-1][len('Packages/NB_FX/'):]
  p=preview if rel=='NBShaders2/ShaderGraph/Editor/NBGraphUnlitSubTarget.cs' else repo/rel
  line='"'+str(p)+'"'
 actual.append(line)
rsp=out/'static-subtarget.rsp';rsp.write_text('\n'.join(actual)+'\n')
sdk='/Applications/Unity/Hub/Editor/6000.3.18f1/Unity.app/Contents/Resources/Scripting/'
p=subprocess.run([sdk+'NetCoreRuntime/dotnet',sdk+'DotNetSdkRoslyn/csc.dll','@'+str(rsp)],cwd=clone,capture_output=True,text=True)
(out/'static-subtarget.log').write_text(p.stdout+p.stderr)
print(p.stdout+p.stderr);print('Offline actual-assembly C# compiler exit:',p.returncode)
(out/'static-subtarget-result.json').write_text(json.dumps({'exitCode':p.returncode,'UnityLaunched':False,'assemblySourceRsp':str(bee/(name+'.rsp')),'rspSHA256':hashlib.sha256(rsp.read_bytes()).hexdigest(),'candidateSHA256':hashlib.sha256(preview.read_bytes()).hexdigest()},indent=2)+'\n')
raise SystemExit(p.returncode)
